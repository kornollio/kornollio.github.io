# Annotating shots from contact sheets

Shot annotation is done by looking at frames. Automatic hit detection on amateur
phone footage turned out to be unreliable: the ball on the far half is only 3–4 px,
and the player's racket is often yellow too. Reading strokes by eye from sheets
takes about 15 minutes per minute of play and gives exact strokes, which the
stats depend on.

## 1. Find rallies and rough contacts (overview)

`sheets.py project.json overview 10` → grids of every 10th frame with burned-in frame numbers.
- A near-player swing shows as racket going back → racket extended in front → follow-through.
- Rallies are separated by people walking or picking up balls. Note who is on the far side.
  The opponent can **change mid-video** (players take turns), so check every rally, and ask the
  user who each person is. Do not label someone "coach" from their clothes.
- At 30 fps an amateur baseline rally has ~100–130 frames between the same player's shots
  (35–70 frames between consecutive shots by either player). A gap of 200+ frames usually
  means a lob, a ball out of frame or the end of the rally.

## 2. Exact contact frame and stroke: near player

`sheets.py project.json window <frame> 24 3 near` → close-ups every 3 frames.
- Contact = the frame where the racket is level with the body and fully extended forward,
  usually with motion blur, and the ball is right next to the strings. Pick that frame (±2 frames is fine).
- **Find handedness first.** The watch is usually on the non-dominant wrist. The off-hand
  points at the incoming ball before a forehand.
- For a right-hander seen **from behind**:
  - Forehand: racket taken back on the image-LEFT, contact on the image-RIGHT side of the
    body, finish over the LEFT shoulder (racket ends up top-left).
  - Backhand: contact on the image-LEFT side, finish over the RIGHT shoulder. A two-hander
    has both hands on the grip during the swing.
  - Mirror both for a left-hander.
- **The finish shoulder is the most reliable cue.** Backswing position is easy to misread
  when the player is running or turned toward the camera.
- Volleys have no bounce before contact and almost no backswing, with the player near the net.
  A serve is an overhead swing from behind the baseline at the start of a rally.

## 3. Far player

`sheets.py project.json window <frame> 33 6 far`. The far player faces the camera, so their
right hand is on the image-LEFT. Contact on the image-left means a forehand for a right-hander.
Resolution is low, so use where the ball meets the racket and which side the follow-through ends on.
If you really cannot tell, write your best guess and flag it to the user.

## 4. Rally outcome

Look at what happens after the last shot: where the ball goes (full frames:
`sheets.py project.json full F1,F2,...`) and who walks off or picks up the ball.
- `"end": "WINNER" | "OUT" | "NET" | "UNKNOWN"` and `"won_by": "<player key>"`.
- For OUT/NET or a winner you can give a rough `"end_bounce": [x, y]` in court metres
  (court model: x 0..10.97 across, y 0 = near baseline .. 23.77 = far baseline).
- Put a short human note in `"note"` (it shows in the summary), e.g. "backhand lob went out".
  Never invent an outcome. If it is not visible, use UNKNOWN and leave `won_by` out.

## Stroke codes

FH, BH, SERVE, VOLLEY, SMASH, LOB, SLICE, DROP (others are shown verbatim).
