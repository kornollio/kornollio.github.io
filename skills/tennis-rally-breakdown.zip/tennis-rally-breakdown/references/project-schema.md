# project.json

One file per video, kept next to the video (or in any folder). All paths are absolute.
Intermediate files go to `<project dir>/work/`.

```json
{
  "video": "/Users/me/Desktop/tennis/game.MOV",
  "output": "/Users/me/Desktop/tennis/Anna — rally breakdown.mp4",
  "lang": "ru",                         // "ru" | "en" — UI labels
  "venue": "Tennistime · грунт",        // subtitle under the title, optional
  "players": {
    "A": {"name": "АННА", "short": "АНН", "side": "near", "hand": "R", "color": "#40c8ff"},
    "O": {"name": "СОПЕРНИЦА", "short": "СОП", "side": "far", "hand": "R", "pick": "dark"},
    "C": {"name": "МАКС", "short": "МАК", "side": "far", "hand": "R", "pick": "bright"}
  },
  "torso_threshold": 170,               // grey level splitting "dark" vs "bright" far players (optional)
  "court_points": {                     // pixel coords in frame 0, names from scripts/common.py
    "near_baseline_left_doubles": [240, 601],
    "near_baseline_right_doubles": [1800, 562],
    "near_service_T": [987, 412],
    "net_post_left_top": [651, 298]
  },
  "rallies": [
    {"name": "Розыгрыш 1", "opp": "O",
     "shots": [[186, "A", "FH"], [239, "O", "FH"], [300, "A", "FH"]],
     "end": "NET", "won_by": "O", "note": "форхенд в сетку"}
  ],
  "trim": {"start": 120, "end": 1896}, // optional, source frame range to render
  "summary_seconds": 3.5,               // freeze-frame summary at the end
  "crop_height_fraction": 0.93,         // optional framing tweaks for the top video area
  "crop_top_fraction": 0.07
}
```

Notes
- Exactly one player has `"side": "near"`. That is the analysed player and appears first everywhere.
- `pick` is only needed when two people stand on the far half (e.g. two people taking turns on the far side):
  `"dark"` / `"bright"` compares torso brightness with `torso_threshold`. People who barely
  move (ball kids, umpire) are filtered out automatically.
- Shot frames are **source video frame indices** (0-based, the numbers burned into contact sheets).
- `court_points`: give at least 4 ground points, spread near and far. Add the 3 net-top points
  (`net_post_left_top`, `net_post_right_top`, `net_center_top`) so heights calibrate properly.
  Ball heights, and therefore the trace and speeds, depend on this.
