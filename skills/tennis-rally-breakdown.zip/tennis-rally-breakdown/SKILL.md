---
name: tennis-rally-breakdown
description: >-
  Turns a phone/tripod video of a tennis match or practice into a vertical "rally breakdown" analysis video in
  the SmartSwing style. Top half is the footage with a ball trace, player tags and stroke + speed pop-ups.
  Bottom half is a live stats panel (shot map, current stroke, est. speed, shots/rally time/fastest, FH/BH
  counts, shot sequence), and a session summary closes the video. Use it whenever someone wants to analyse a
  tennis (or padel/pickleball-style court) video. Typical asks: break down strokes, count forehands/backhands,
  estimate ball speed, make a shot map, "сделай разбор игры/ударов", "аналитическое видео как у SmartSwing",
  or turn a match clip into a reel with stats. Trigger even if they only say "проанализируй видео с теннисом"
  or send a court video plus an example of such a reel.
---

# Tennis rally breakdown

Pipeline: track people and ball → calibrate the court and camera → **annotate shots by eye** →
fit ball flights to the detected ball → render a 1080×1920 video with the stats panel.

The output looks like a pro analytics product, so accuracy and honesty matter more than speed.
Every number shown must come from either verified annotation (who hit, which stroke, when)
or a measurement you can explain (fitted trajectory). Tell the user which numbers are estimates.

All scripts are in `scripts/` next to this file. Run them with the venv python from step 0.
Each takes the path of a `project.json` (schema: `references/project-schema.md`).

## 0. Setup (once per machine)

```bash
PY=$(zsh <skill>/scripts/setup.sh)      # creates ~/.cache/tennis-rally-breakdown/venv, prints its python
```
You need macOS with ffmpeg (brew). YOLO weights download on first run. On Apple Silicon it runs on MPS.

## 1. Look before you do anything

- `ffprobe` the video for resolution, fps and audio streams. Extract a few frames and look at them.
- If there is an example reel, extract frames from it too. Its layout is the target. `render.py`
  already implements the SmartSwing layout. Adapt colours or labels if the example differs.
- Ask the user only what you cannot see: player names, which player to analyse (the one nearer
  the camera is the default), and the UI language (default: the language the user writes in).
- Create the project folder and a `project.json` with `video`, `output`, `lang`, `players` (names, sides).

## 2. Tracking pass (~3–6 min per minute of 1080p video)

```bash
cd <skill>/scripts
$PY track.py /path/project.json     # people + rackets (YOLO) and camera motion -> work/track.json
$PY ball.py  /path/project.json     # ball candidates (3-frame differencing + colour) -> work/ball.json
```
Run them in the background and work on step 3 meanwhile. `track.py` needs nothing from step 3.

## 3. Court and camera calibration

- Open frame 0 at full resolution plus zoomed crops (Pillow), and read off the pixel coordinates
  of court keypoints: baseline corners, singles corners, service-line ends, the T, net post
  bottoms and tops, the net-centre top. Names are in `common.py` (`COURT_KP`, `COURT_KP3`).
- Put them in `project.json → court_points`, then run `$PY court.py project.json`.
- **Open `work/court_check.jpg`.** The magenta lines must lie on the painted lines and the yellow
  line on the net tape. Fix points until they do. Typical result: reprojection error 2–6 px, a
  plausible camera position (a few metres behind the baseline, 1.5–4 m high). With a strong
  ultrawide lens the far side drifts a little. That is acceptable.

## 4. Shot annotation (the important part)

Read `references/annotation.md`, then:
1. `sheets.py project.json overview 10` → find the rallies, the opponent in each, and rough swing times.
2. For every swing, `sheets.py project.json window <f> 24 3 near` (or `... 33 6 far`) → exact
   contact frame and stroke. The finish shoulder is the reliable cue.
3. Write `rallies` into `project.json`: shots as `[frame, playerKey, stroke]`, plus `end`, `won_by`, `note`.
4. **Confirm the facts you could not see clearly with the user before rendering.** Who the people
   are (a partner can look like a coach), who won each rally, and where the last ball went (net or out).
   These are hard to read from a distant camera and easy for the user to answer. Getting them wrong
   makes the whole video look untrustworthy. A short list is enough: "rally 1: the near player's backhand
   lob — winner or out? rally 2: last forehand — net or long?"

Keep the user informed with one-line updates (how many shots found so far, any surprises such
as the opponent changing). If a stroke is genuinely ambiguous, say so rather than guessing silently.

## 5. Analysis

```bash
$PY analyze.py project.json
```
For each shot it puts the hitter on the court, builds a physical flight (contact → bounce →
next contact), and then makes the trace follow the real ball:
1. Coarse fit to the candidates from `ball.py`.
2. Two or three **guided detection** passes. Around the predicted position in every flight frame,
   it searches for a faint moving yellow blob in a window scaled to the ball's apparent size.
   That window is ~1.5 m in court units: small far away, large near the camera, where the ball
   is big and blurred. These passes find balls the global detector misses: pale balls against
   walls and fences, blurred balls just before the near player's contact.
3. **Joint fit of the whole flight** (contact → bounce → receiver contact). The well-seen
   near-side leg pins down where the far player's ball bounced.
4. The rendered trace is **snapped to the ball** in every frame where it was seen. Outliers are
   rejected and the trace smoothed. The model only fills the gaps.

End types change the last flight. `WINNER` must bounce in the court. `NET` stops at the net on
the hitter's side. `OUT`/`UNKNOWN` may land anywhere.

Check the printed table and the summary line:
- Healthy: the ball is seen in 70%+ of flight frames and the median error is ≤ 5 px. A per-flight
  error above ~15 px means that flight's model is poor. Look at it with `qa_trace.py`.
- Speeds of 40–90 km/h are typical for amateurs and 100+ for strong players. An outlier usually
  means a wrong contact frame. Re-check that window and fix the annotation, don't fudge the number.
- `fit-pinned` = depth/height ambiguity. The bounce stays modelled.

Then **look at the trace on real frames**:
```bash
$PY qa_trace.py project.json 200,250,330,520,700,1240   # mix of far-side flights, pre-contact, post-bounce
```
The real ball must sit inside the green circle. Users notice at once when the drawn ball and the
real ball fly apart, so do not skip this. If they diverge, find the cause on the frames (ball
not detected? wrong contact frame? false blobs on a player?) and fix that, rather than tweaking numbers.

## 6. Preview, then render

```bash
$PY render.py project.json --preview 400,900,1500   # pick frames mid-flight, right after a hit, and in the summary
```
Look at the previews: the trace should sit on the real ball, the tags on the players, the
pop-up must not cover the player, and nothing may overflow the panel. Then:
```bash
$PY render.py project.json            # ~1 min per minute of video
zsh finalize.sh project.json          # adds the source audio -> project["output"]
```
Send the user the final file.

## 7. Report honestly

In the final message, separate:
- **Verified:** who hit, the stroke type, timing, rally count and outcome (checked frame by frame).
- **Measured, with error bars:** trajectories, bounce points and speeds come from fitting the ball
  detections. Report the share of flight frames where the ball was seen and the median px error, and give speeds as
  "~" (roughly ±10 km/h). Depth is only meaningful for fitted flights.
- Everything else is a modelled approximation.

Don't put claims in the summary that the data can't support. `render.py` only draws a depth
takeaway when at least half of the in-court balls were fitted, for exactly this reason.

## Known limitations / tips

- Low, wide camera behind one baseline is the expected setup. The near player must be visible
  most of the time. The camera may drift slightly (stabilised against the top of the frame),
  but strong panning or zooming breaks calibration.
- Far-side ball detection is the weak spot: 3–4 px, desaturated against fences. Higher
  resolution and fps (4K/60) help a lot. Tell the user this when the fitted share is low.
- A yellow racket or yellow clothing creates false ball candidates. The fit's gating handles
  most of them. Check the alignment number.
- If the video has several points, every rally gets its own entry. Stats in the panel are per
  rally, and the summary covers all of them.
