"""Ball candidates per frame: 3-frame differencing + soft yellow/bright gate, racket masking.

usage: ball.py project.json
writes work/ball.json  (list per frame of [x, y, area] in FRAME pixel coords)
Candidates are noisy on purpose - fit.py gates them against the physical model.
"""
import sys, json
import numpy as np, cv2
from common import load_project, work, frames

p = load_project(sys.argv[1])
tr = json.load(open(work(p, "track.json"))); W, H = tr["w"], tr["h"]; F = tr["frames"]
sc = H / 1080.0
amin, amax, smax = max(2, int(2 * sc * sc)), int(400 * sc * sc), int(45 * sc)

buf = []; res = [[]]
for i, cur in frames(p["video"], W, H, "bgr24"):
    buf.append(cur)
    if len(buf) < 3: continue
    prv, cur_, nxt = buf[-3:]; buf = buf[-2:]
    k = i - 1                                   # index of the middle frame
    g = [cv2.cvtColor(x, cv2.COLOR_BGR2GRAY).astype(np.int16) for x in (prv, cur_, nxt)]
    mot = ((np.abs(g[1] - g[0]) > 10) & (np.abs(g[1] - g[2]) > 10))
    hsv = cv2.cvtColor(cur_, cv2.COLOR_BGR2HSV)
    col = cv2.inRange(hsv, (20, 45, 95), (50, 255, 255)) > 0
    bright = (hsv[..., 2] > 150) & (hsv[..., 1] > 25) & (hsv[..., 0] > 18) & (hsv[..., 0] < 55)
    mk = (mot & (col | bright)).astype(np.uint8)
    mk = cv2.morphologyEx(mk, cv2.MORPH_CLOSE, np.ones((3, 3), np.uint8))
    n, lab, st, cen = cv2.connectedComponentsWithStats(mk)
    rk = F[k]["racket"]; big = [b for b in F[k]["people"] if b[3] > 0.4 * H]
    cands = []
    for j in range(1, n):
        a = st[j, 4]
        x, y = cen[j]
        lowf = 1.0 if y < 0.5 * H else 1 + 5 * (y / H - 0.5)          # near the camera the (blurred) ball is much bigger
        if not (amin <= a <= amax * lowf * lowf) or max(st[j, 2], st[j, 3]) > smax * lowf * 1.6: continue
        if any(b[0] - 15 < x < b[2] + 15 and b[1] - 15 < y < b[3] + 15 for b in rk) and a > 30 * sc * sc: continue
        cands.append([float(x), float(y), int(a)])
    res.append(cands)
res.append([])
json.dump(res, open(work(p, "ball.json"), "w"))
print("frames", len(res), "with candidates", sum(1 for c in res if c))
