"""Court calibration from hand-picked keypoints (reference frame = frame 0 after stabilisation).

usage: court.py project.json [frame_index]
  - reads project["court_points"]: {keypoint_name: [px, py], ...}  (names from common.COURT_KP / COURT_KP3)
  - fits ground homography + full camera (solvePnP, focal length scanned)
  - writes work/cam.json and work/court_check.jpg (court lines re-projected in magenta) - LOOK at it.
Needs >= 4 ground points (more is better, spread near+far) and ideally the 3 net-top points for height.
"""
import sys, json
import numpy as np, cv2
from common import load_project, work, frames, probe, COURT_KP, COURT_KP3

p = load_project(sys.argv[1]); fi = int(sys.argv[2]) if len(sys.argv) > 2 else 0
W, H, _, _ = probe(p["video"])
pts = p["court_points"]
g_img, g_crt, o3, i3 = [], [], [], []
for name, xy in pts.items():
    if name in COURT_KP:
        g_img.append(xy); g_crt.append(COURT_KP[name]); o3.append((*COURT_KP[name], 0)); i3.append(xy)
    elif name in COURT_KP3:
        o3.append(COURT_KP3[name]); i3.append(xy)
    else:
        sys.exit(f"unknown keypoint {name}; allowed: {list(COURT_KP) + list(COURT_KP3)}")
if len(g_img) < 4: sys.exit("need at least 4 ground keypoints")
Hc, _ = cv2.findHomography(np.float32(g_crt), np.float32(g_img), cv2.RANSAC if len(g_img) > 5 else 0, 6.0)
gerr = np.hypot(*(cv2.perspectiveTransform(np.float32(g_crt).reshape(-1, 1, 2), Hc).reshape(-1, 2) - np.float32(g_img)).T)

o3 = np.float64(o3); i3 = np.float64(i3); best = None
for f in range(int(0.25 * W), int(2.5 * W), 5):
    K = np.array([[f, 0, W / 2], [0, f, H / 2], [0, 0, 1.]])
    ok, r, t = cv2.solvePnP(o3, i3, K, None, flags=cv2.SOLVEPNP_ITERATIVE)
    if not ok: continue
    q, _ = cv2.projectPoints(o3, r, t, K, None); e = np.hypot(*(q[:, 0] - i3).T).mean()
    if best is None or e < best[0]: best = (e, f, r, t, K)
e, f, r, t, K = best
R, _ = cv2.Rodrigues(r); campos = (-R.T @ t).ravel()
json.dump({"Hc": Hc.tolist(), "K": K.tolist(), "r": r.ravel().tolist(), "t": t.ravel().tolist(),
           "focal": f, "reproj_err_px": float(e), "camera_pos_m": campos.tolist()}, open(work(p, "cam.json"), "w"))

for _, im in frames(p["video"], W, H, "bgr24", select=[fi]): img = im.copy()
L = [((0, 0), (10.97, 0)), ((0, 23.77), (10.97, 23.77)), ((0, 0), (0, 23.77)), ((10.97, 0), (10.97, 23.77)),
     ((1.37, 0), (1.37, 23.77)), ((9.6, 0), (9.6, 23.77)), ((1.37, 5.485), (9.6, 5.485)), ((1.37, 18.285), (9.6, 18.285)),
     ((5.485, 5.485), (5.485, 18.285))]
for a, b in L:
    q, _ = cv2.projectPoints(np.float64([(*a, 0), (*b, 0)]), r, t, K, None); q = q.reshape(-1, 2).astype(int)
    cv2.line(img, tuple(q[0]), tuple(q[1]), (255, 0, 255), 2)
q, _ = cv2.projectPoints(np.float64([(-0.914, 11.885, 1.07), (5.485, 11.885, 0.914), (11.884, 11.885, 1.07)]), r, t, K, None)
q = q.reshape(-1, 2).astype(int)
cv2.polylines(img, [q], False, (0, 255, 255), 2)
for xy in i3: cv2.circle(img, (int(xy[0]), int(xy[1])), 6, (0, 255, 0), 2)
cv2.imwrite(work(p, "court_check.jpg"), img)
print(f"ground homography err median {np.median(gerr):.1f}px max {gerr.max():.1f}px")
print(f"camera: focal {f}px, reprojection {e:.1f}px, position (m) x={campos[0]:.1f} y={campos[1]:.1f} z={campos[2]:.1f}")
print("check", work(p, "court_check.jpg"))
