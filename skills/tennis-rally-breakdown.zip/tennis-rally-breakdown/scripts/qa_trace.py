"""Visual QA of the ball trace: crops around the trace head at given frames (green = trace, circle = head).

usage: qa_trace.py project.json F1,F2,...      -> work/qa_trace_<F1>.jpg
Pick frames across the video: mid-flight on the far side, just before the near player's contact,
right after a bounce. The real ball should sit inside the green circle.
"""
import sys, json
import numpy as np, cv2
from common import load_project, work, frames

p = load_project(sys.argv[1]); D = json.load(open(work(p, "shots.json"))); W, H = D["w"], D["h"]
fr = [int(x) for x in sys.argv[2].split(",")]; tiles = []; sc = H / 1080
for f, im in frames(p["video"], W, H, "bgr24", select=fr):
    im = im.copy(); s = None
    for r in D["rallies"]:
        for q in r["shots"]:
            if q["f"] <= f < q["fEnd"]: s = q
    if s:
        pts = np.array([s["trace"][str(t)] for t in range(max(s["f"], f - 10), f + 1)]).astype(int)
        cv2.polylines(im, [pts], False, (0, 255, 0), max(1, int(2 * sc))); cx, cy = pts[-1]
        cv2.circle(im, (cx, cy), int(14 * sc), (0, 255, 0), max(1, int(2 * sc)))
    else:
        cx, cy = W // 2, H // 2
    cw, ch = int(400 * sc), int(260 * sc)
    x0 = int(min(max(cx - cw // 2, 0), W - cw)); y0 = int(min(max(cy - ch // 2, 0), H - ch))
    t = cv2.resize(im[y0:y0 + ch, x0:x0 + cw], (600, 390))
    cv2.putText(t, str(f) + ("" if s else " (no flight)"), (5, 25), 0, 0.8, (0, 255, 255), 2); tiles.append(t)
rows = [np.hstack(tiles[i:i + 4] + [np.zeros_like(tiles[0])] * (4 - len(tiles[i:i + 4]))) for i in range(0, len(tiles), 4)]
out = work(p, f"qa_trace_{fr[0]}.jpg"); cv2.imwrite(out, np.vstack(rows)); print(out)
