"""Shared helpers: project config, video IO, court geometry, camera projection."""
import json, os, subprocess
import numpy as np, cv2

# Court model, metres. x across (0..10.97, left doubles line seen from the near baseline),
# y along (0 = near baseline .. 23.77 = far baseline). z up.
COURT_KP = {
    "near_baseline_left_doubles": (0, 0), "near_baseline_right_doubles": (10.97, 0),
    "near_baseline_left_singles": (1.37, 0), "near_baseline_right_singles": (9.60, 0),
    "near_baseline_center": (5.485, 0),
    "near_service_left": (1.37, 5.485), "near_service_right": (9.60, 5.485), "near_service_T": (5.485, 5.485),
    "net_center_bottom": (5.485, 11.885),
    "net_post_left_bottom": (-0.914, 11.885), "net_post_right_bottom": (11.884, 11.885),
    "far_service_left": (1.37, 18.285), "far_service_right": (9.60, 18.285), "far_service_T": (5.485, 18.285),
    "far_baseline_left_doubles": (0, 23.77), "far_baseline_right_doubles": (10.97, 23.77),
    "far_baseline_left_singles": (1.37, 23.77), "far_baseline_right_singles": (9.60, 23.77),
    "far_baseline_center": (5.485, 23.77),
}
# 3D points with height (net) - used only for camera calibration
COURT_KP3 = {
    "net_post_left_top": (-0.914, 11.885, 1.07), "net_post_right_top": (11.884, 11.885, 1.07),
    "net_center_top": (5.485, 11.885, 0.914),
}
NET_Y = 11.885; G = 9.81


def load_project(path):
    p = json.load(open(path))
    p["_dir"] = os.path.dirname(os.path.abspath(path))
    return p


def work(p, name):
    d = os.path.join(p["_dir"], p.get("workdir", "work"))
    os.makedirs(d, exist_ok=True)
    return os.path.join(d, name)


def probe(video):
    out = subprocess.check_output(["ffprobe", "-v", "error", "-select_streams", "v:0", "-show_entries",
                                   "stream=width,height,r_frame_rate,nb_frames:stream_side_data=rotation",
                                   "-of", "json", video])
    s = json.loads(out)["streams"][0]
    num, den = map(int, s["r_frame_rate"].split("/"))
    return int(s["width"]), int(s["height"]), num / den, s["r_frame_rate"]


def frames(video, w, h, fmt="rgb24", select=None):
    """yield (index, frame). select: sorted list of frame indices to decode-and-return (others skipped)."""
    ch = 3 if fmt in ("rgb24", "bgr24") else 1
    proc = subprocess.Popen(["ffmpeg", "-v", "error", "-i", video, "-f", "rawvideo", "-pix_fmt", fmt, "-"],
                            stdout=subprocess.PIPE, bufsize=w * h * ch * 4)
    want = set(select) if select is not None else None
    last = max(select) if select else None
    i = 0
    try:
        while True:
            b = proc.stdout.read(w * h * ch)
            if len(b) < w * h * ch: break
            if want is None or i in want:
                shape = (h, w, ch) if ch == 3 else (h, w)
                yield i, np.frombuffer(b, np.uint8).reshape(shape)
            if last is not None and i >= last: break
            i += 1
    finally:
        proc.kill()


class Geo:
    """Ground homography + full camera model in the reference frame, plus per-frame camera motion."""
    def __init__(self, p):
        cam = json.load(open(work(p, "cam.json")))
        self.Hc = np.array(cam["Hc"]); self.Hinv = np.linalg.inv(self.Hc)
        self.K = np.array(cam["K"]); self.r = np.array(cam["r"]); self.t = np.array(cam["t"])
        tr = json.load(open(work(p, "track.json")))
        self.Hf = [np.array(x["H"]) for x in tr["frames"]]          # frame -> reference

    def frame_to_ref(self, f, pts):
        return cv2.perspectiveTransform(np.float64(pts).reshape(-1, 1, 2), self.Hf[f]).reshape(-1, 2)

    def ref_to_frame(self, f, pts):
        return cv2.perspectiveTransform(np.float64(pts).reshape(-1, 1, 2), np.linalg.inv(self.Hf[f])).reshape(-1, 2)

    def img_to_court(self, f, pts):
        ref = self.frame_to_ref(f, pts)
        return cv2.perspectiveTransform(ref.reshape(-1, 1, 2), self.Hinv).reshape(-1, 2)

    def court3_to_ref(self, P):
        q, _ = cv2.projectPoints(np.float64(P).reshape(-1, 1, 3), self.r, self.t, self.K, None)
        return q.reshape(-1, 2)

    def court3_to_frame(self, f, P):
        return self.ref_to_frame(f, self.court3_to_ref(P))
