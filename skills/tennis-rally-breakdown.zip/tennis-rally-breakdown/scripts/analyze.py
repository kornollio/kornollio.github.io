"""Shots -> court positions, ball flights fitted to detected ball, speeds, depth.

usage: analyze.py project.json
needs work/track.json, work/ball.json, work/cam.json and project["rallies"] (annotated contacts).
writes work/shots.json and prints a per-shot table + alignment error (model vs real ball, px).
"""
import sys, json
import numpy as np, cv2
from scipy.ndimage import gaussian_filter1d
from scipy.optimize import least_squares
from common import load_project, work, frames, Geo, NET_Y, G

p = load_project(sys.argv[1]); geo = Geo(p)
tr = json.load(open(work(p, "track.json"))); W, H, FPS = tr["w"], tr["h"], tr["fps"]; F = tr["frames"]; N = len(F)
cand = json.load(open(work(p, "ball.json")))
players = p["players"]

# ---------- player positions ----------
def feet(b): return [(b[0] + b[2]) / 2, b[3]]
dets = []   # per frame: list of (box, court_xy)
for i, fr in enumerate(F):
    bs = [b for b in fr["people"] if b[4] > 0.25]
    cs = geo.img_to_court(i, [feet(b) for b in bs]) if bs else []
    dets.append(list(zip(bs, [tuple(c) for c in cs])))

# static people (ball kids, umpire, spectators) occupy the same 0.5 m cell for most of the video
occ = {}
for d in dets:
    for _, c in d: occ[(round(c[0] * 2), round(c[1] * 2))] = occ.get((round(c[0] * 2), round(c[1] * 2)), 0) + 1
static = {k for k, v in occ.items() if v > 0.55 * N}

need_torso = any(v.get("pick") in ("dark", "bright") for v in players.values())
torso = [[None] * len(d) for d in dets]
if need_torso:
    for i, g in frames(p["video"], W, H, "gray"):
        for j, (b, c) in enumerate(dets[i]):
            if c[1] > NET_Y:
                x1, y1, x2, y2 = b[:4]; h = y2 - y1
                t = g[int(y1 + 0.2 * h):int(y1 + 0.5 * h), int(x1 + 0.25 * (x2 - x1)):int(x2 - 0.25 * (x2 - x1))]
                torso[i][j] = float(t.mean()) if t.size else None
thr = p.get("torso_threshold", 170)

def pick(i, key):
    pl = players[key]; best = None
    for j, (b, c) in enumerate(dets[i]):
        if (round(c[0] * 2), round(c[1] * 2)) in static: continue
        if pl["side"] == "near":
            if not (-10 < c[1] < NET_Y - 0.5 and -4 < c[0] < 15): continue
            score = b[3] - b[1]
        else:
            if not (NET_Y + 0.5 < c[1] < 31 and -4 < c[0] < 15): continue
            tb = torso[i][j]
            if pl.get("pick") == "dark" and (tb is None or tb > thr): continue
            if pl.get("pick") == "bright" and (tb is None or tb <= thr): continue
            score = b[4]
        if best is None or score > best[0]: best = (score, b, c)
    return best

track = {}
for key in players:
    bx = np.full((N, 4), np.nan); cx = np.full((N, 2), np.nan)
    for i in range(N):
        r = pick(i, key)
        if r: bx[i] = r[1][:4]; cx[i] = r[2]
    ok = ~np.isnan(cx[:, 0]); idx = np.arange(N)
    if ok.sum() < 2: print("WARNING: player", key, "almost never found"); ok[:] = False; continue
    for arr in (bx, cx):
        for k in range(arr.shape[1]):
            arr[:, k] = gaussian_filter1d(np.interp(idx, idx[ok], arr[ok, k]), 2)
    track[key] = {"box": bx.tolist(), "court": cx.tolist(), "seen": ok.tolist()}
    print(f"player {key} ({players[key]['name']}): found in {ok.mean() * 100:.0f}% of frames")


# ---------- shots ----------
SC = H / 1080.0

def contact(f, who, stroke):
    c = np.array(track[who]["court"][f]); pl = players[who]
    near = pl["side"] == "near"; hand = 1 if pl.get("hand", "R") == "R" else -1
    side = hand * (1 if stroke in ("FH", "SERVE", "SMASH") else -1)
    return c + [0.65 * side * (1 if near else -1), 0.35 if near else -0.35]

def pre_pts(A, z0, P, t1, taus):
    vz = (-z0 + 0.5 * G * t1 * t1) / t1; u = (np.asarray(taus) / t1)[:, None]
    return np.c_[A + (np.asarray(P) - A) * u, z0 + vz * taus - 0.5 * G * np.asarray(taus) ** 2]

def post_pts(P, B, zc, t2, taus, end_vel=None):
    taus = np.asarray(taus)
    if B is None:                                   # no receiver: keep rolling/bouncing in the same direction
        h = np.asarray(P) + end_vel * taus[:, None]; vz = 3.0
    else:
        h = np.asarray(P) + (np.asarray(B) - np.asarray(P)) * (taus / t2)[:, None]; vz = (zc + 0.5 * G * t2 * t2) / t2
    return np.c_[h, np.maximum(0, vz * taus - 0.5 * G * taus ** 2)]

# ---- flights: build initial model ----
flights = []           # one per shot
for ri, r in enumerate(p["rallies"]):
    S = r["shots"]
    for k, (f, who, st) in enumerate(S):
        A = contact(f, who, st); near = A[1] < NET_Y; last = k + 1 == len(S); end = r.get("end", "UNKNOWN") if last else None
        if not last:
            f2, who2, st2 = S[k + 1]; B = contact(f2, who2, st2); T = (f2 - f) / FPS
            u = (B - A) / np.linalg.norm(B - A); P0 = B - u * p.get("bounce_before_contact_m", 3.5)
            P0[1] = max(P0[1], NET_Y + 1.5) if near else min(P0[1], NET_Y - 1.5)
            d1 = np.linalg.norm(P0 - A); d2 = np.linalg.norm(B - P0); t10 = d1 / ((d1 + d2 / 0.62) / T)
            ylo, yhi = (NET_Y + 1.5, 23.78) if near else (-0.02, NET_Y - 1.5); xlo, xhi = 1.38, 9.59
        else:
            B = None; f2 = None
            if end == "NET":
                eb = r.get("end_bounce") or [A[0], NET_Y - 0.4 if near else NET_Y + 0.4]
                ylo, yhi = (NET_Y - 1.2, NET_Y - 0.05) if near else (NET_Y + 0.05, NET_Y + 1.2); xlo, xhi = -1, 12
            elif end == "WINNER":
                eb = r.get("end_bounce") or [5.485, 19 if near else 4.8]
                ylo, yhi = (NET_Y + 0.5, 23.8) if near else (-0.05, NET_Y - 0.5); xlo, xhi = 1.3, 9.7
            else:   # OUT / UNKNOWN
                eb = r.get("end_bounce") or [5.485, 22 if near else 1.8]
                ylo, yhi = (NET_Y + 0.5, 29) if near else (-5.5, NET_Y - 0.5); xlo, xhi = -4, 15
            P0 = np.array(eb, float); t10 = np.linalg.norm(P0 - A) / 15.0
        P0 = np.clip(P0, [xlo + 1e-3, ylo + 1e-3], [xhi - 1e-3, yhi - 1e-3])
        flights.append(dict(r=ri, k=k, f=f, who=who, st=st, A=A, B=B, f2=f2, end=end, P0=P0, t10=float(np.clip(t10, .45, 2.4)),
                            bounds=(xlo, xhi, ylo, yhi), dA=np.zeros(2), z0=0.95, P=P0.copy(), t1=float(np.clip(t10, .45, 2.4)),
                            zc=1.0, dB=np.zeros(2), src="model"))

def fl_end(fl):
    return fl["f2"] if fl["f2"] else int(fl["f"] + (fl["t1"] + 0.8) * FPS)

def fl_court(fl, fr):
    """court 3D position of the ball at (possibly fractional) frames fr for flight fl"""
    fr = np.atleast_1d(np.asarray(fr, float)); tau = (fr - fl["f"]) / FPS
    A = fl["A"] + fl["dA"]; out = np.zeros((len(fr), 3)); pre = tau <= fl["t1"]
    if pre.any(): out[pre] = pre_pts(A, fl["z0"], fl["P"], fl["t1"], tau[pre])
    if (~pre).any():
        t2 = (fl["f2"] - fl["f"]) / FPS - fl["t1"] if fl["f2"] else None
        B = fl["B"] + fl["dB"] if fl["B"] is not None else None
        ev = (fl["P"] - A) / fl["t1"] * (0.15 if fl["end"] == "NET" else 0.6)
        out[~pre] = post_pts(fl["P"], B, fl["zc"], max(t2 or 1, .1), tau[~pre] - fl["t1"], ev)
    return out

def fl_frame_px(fl, fr):
    fr = np.atleast_1d(fr); pts = fl_court(fl, fr)
    return np.array([geo.court3_to_frame(int(round(f)), [q])[0] for f, q in zip(fr, pts)])

# ---- coarse observations from ball.json ----
def coarse_obs(fl, gate_px):
    obs = {}
    frs = np.arange(fl["f"] + 1, fl_end(fl))
    pr = fl_frame_px(fl, frs)
    for f, q in zip(frs, pr):
        c = cand[f] if f < len(cand) else []
        if not c: continue
        c = np.array([x[:2] for x in c]); d = np.hypot(*(c - q).T); j = d.argmin()
        g = gate_px(f) if callable(gate_px) else gate_px
        if d[j] < g: obs[int(f)] = c[j]
    return obs

# ---- guided detection: look for a faint moving ball right where the flight model says it is ----
def px_per_m(f, P3):
    q = geo.court3_to_frame(f, [P3, [P3[0] + 0.5, P3[1], P3[2]]]); return 2 * np.hypot(*(q[1] - q[0]))

def guided(flist, k):
    need = {}
    for fl in flist:
        frs = np.arange(fl["f"] + 2, fl_end(fl) - 1); c3 = fl_court(fl, frs)
        for f, q, P3 in zip(frs, fl_frame_px(fl, frs), c3):
            R = float(np.clip(k * px_per_m(int(f), P3), 30 * SC, 260 * SC))
            need.setdefault(int(f), []).append((id(fl), q, R))
    sel = sorted({g for f in need for g in (f - 1, f, f + 1) if 0 <= g < N})
    buf = {}; found = {}
    for i, fr in frames(p["video"], W, H, "bgr24", select=sel):
        buf[i] = fr
        for c in (i - 1,):
            if c in need and c - 1 in buf and c + 1 in buf:
                for fid, q, R in need[c]:
                    x0, y0 = int(max(0, q[0] - R)), int(max(0, q[1] - R)); x1, y1 = int(min(W, q[0] + R)), int(min(H, q[1] + R))
                    if x1 - x0 < 8 or y1 - y0 < 8: continue
                    g = [cv2.cvtColor(buf[j][y0:y1, x0:x1], cv2.COLOR_BGR2GRAY).astype(np.int16) for j in (c - 1, c, c + 1)]
                    dmin = np.minimum(np.abs(g[1] - g[0]), np.abs(g[1] - g[2])).astype(np.float32)
                    hsv = cv2.cvtColor(buf[c][y0:y1, x0:x1], cv2.COLOR_BGR2HSV)
                    ball = ((hsv[..., 0] >= 22) & (hsv[..., 0] <= 58) & (hsv[..., 1] > 28) & (hsv[..., 2] > 100)).astype(np.float32)
                    sc = cv2.GaussianBlur(dmin * (0.3 + 0.7 * ball), (3, 3), 0)
                    yy, xx = np.mgrid[y0:y1, x0:x1]
                    prox = np.exp(-((xx - q[0]) ** 2 + (yy - q[1]) ** 2) / (2 * (0.55 * R) ** 2))
                    m = sc * prox; j = np.unravel_index(m.argmax(), m.shape)
                    if dmin[j] < 7 or sc[j] < 6: continue
                    mk = (sc > max(5, 0.45 * sc[j])).astype(np.uint8); n, lab, st, cen = cv2.connectedComponentsWithStats(mk)
                    L = lab[j]
                    big = max(1.0, R / (60 * SC))
                    if L == 0 or st[L, 4] > 320 * SC * SC * big * big or max(st[L, 2], st[L, 3]) > 42 * SC * big: continue
                    px, py = cen[L][0] + x0, cen[L][1] + y0
                    if any(b[0] - 8 < px < b[2] + 8 and b[1] - 8 < py < b[3] + 8 for b in F[c]["racket"]) and st[L, 4] > 40 * SC * SC: continue
                    found[(fid, c)] = np.array([px, py])
        for k in [k for k in buf if k < i - 2]: del buf[k]
    return found

# ---- fitting ----
def fit_pre(fl, obs):
    frs = np.array([f for f in obs if f <= fl["f"] + fl["t1"] * FPS + 2], float)
    if len(frs) < 5: return False
    xy = np.array([obs[int(f)] for f in frs]); xy_ref = np.array([geo.frame_to_ref(int(f), [q])[0] for f, q in zip(frs, xy)])
    A = fl["A"]; P0 = fl["P0"]; t10 = fl["t10"]; xlo, xhi, ylo, yhi = fl["bounds"]
    def res(q):
        pr = geo.court3_to_ref(pre_pts(A + q[:2], q[2], q[3:5], q[5], (frs - fl["f"]) / FPS))
        prior = [q[0] / .5, q[1] / .5, (q[2] - .95) / .5, (q[3] - P0[0]) / 5, (q[4] - P0[1]) / 5, (q[5] - t10) / .35]
        return np.r_[(pr - xy_ref).ravel() / (4.0 * SC), prior]
    lo = [-1, -1, .3, xlo, ylo, .4]; hi = [1, 1, 2.8, xhi, yhi, 2.5]
    q0 = np.clip([*fl["dA"], fl["z0"], *fl["P"], fl["t1"]], np.add(lo, 1e-6), np.subtract(hi, 1e-6))
    q = least_squares(res, q0, bounds=(lo, hi), loss="soft_l1", f_scale=1.5).x
    pinned = abs(q[4] - ylo) < .05 or abs(q[4] - yhi) < .05
    if pinned and fl["end"] is None:      # depth/height ambiguity: keep modelled bounce, fit height + time
        def r2(q):
            pr = geo.court3_to_ref(pre_pts(A, q[0], P0, q[1], (frs - fl["f"]) / FPS))
            return np.r_[(pr - xy_ref).ravel() / (4.0 * SC), (q[0] - .95) / .5, (q[1] - t10) / .35]
        q2 = least_squares(r2, [0.95, float(np.clip(t10, .41, 2.49))], bounds=([.3, .4], [2.8, 2.5]), loss="soft_l1", f_scale=1.5).x
        fl.update(dA=np.zeros(2), z0=float(q2[0]), P=P0.copy(), t1=float(q2[1]), src="fit-pinned")
    else:
        fl.update(dA=q[:2], z0=float(q[2]), P=q[3:5].copy(), t1=float(q[5]), src="fit")
    return True

def fit_post(fl, obs):
    if fl["B"] is None or not fl["f2"]: return
    fP = fl["f"] + fl["t1"] * FPS; t2 = (fl["f2"] - fP) / FPS
    if t2 < 0.15: return
    frs = np.array([f for f in obs if fP + 1 < f < fl["f2"]], float)
    if len(frs) < 3: return
    xy_ref = np.array([geo.frame_to_ref(int(f), [obs[int(f)]])[0] for f in frs])
    def res(q):
        pr = geo.court3_to_ref(post_pts(fl["P"], fl["B"] + q[1:3], q[0], t2, (frs - fP) / FPS))
        return np.r_[(pr - xy_ref).ravel() / (4.0 * SC), (q[0] - 1.0) / .5, q[1] / .8, q[2] / .8]
    q = least_squares(res, [1.0, 0, 0], bounds=([.2, -2, -2], [2.6, 2, 2]), loss="soft_l1", f_scale=1.5).x
    fl.update(zc=float(q[0]), dB=q[1:3].copy())


def fit_joint(fl, obs):
    """fit the whole flight (contact -> bounce -> receiver contact) to all observations at once"""
    if fl["B"] is None or not fl["f2"]: return fit_pre(fl, obs)
    frs = np.array(sorted(f for f in obs if fl["f"] < f < fl["f2"]), float)
    if len(frs) < 6: return fit_pre(fl, obs)
    xy_ref = np.array([geo.frame_to_ref(int(f), [obs[int(f)]])[0] for f in frs])
    A = fl["A"]; B = fl["B"]; P0 = fl["P0"]; t10 = fl["t10"]; xlo, xhi, ylo, yhi = fl["bounds"]; Ttot = (fl["f2"] - fl["f"]) / FPS
    def pts(q):
        dA, z0, P, t1, zc, dB = q[:2], q[2], q[3:5], q[5], q[6], q[7:9]
        tau = (frs - fl["f"]) / FPS; out = np.zeros((len(frs), 3)); pre = tau <= t1
        if pre.any(): out[pre] = pre_pts(A + dA, z0, P, t1, tau[pre])
        if (~pre).any(): out[~pre] = post_pts(P, B + dB, zc, max(Ttot - t1, .1), tau[~pre] - t1)
        return out
    def res(q):
        pr = geo.court3_to_ref(pts(q))
        prior = [q[0] / .5, q[1] / .5, (q[2] - .95) / .5, (q[3] - P0[0]) / 6, (q[4] - P0[1]) / 6, (q[5] - t10) / .4,
                 (q[6] - 1.0) / .5, q[7] / .8, q[8] / .8]
        return np.r_[(pr - xy_ref).ravel() / (4.0 * SC), prior]
    lo = [-1, -1, .3, xlo, ylo, .4, .2, -2, -2]; hi = [1, 1, 2.8, xhi, yhi, min(2.5, Ttot - .1), 2.6, 2, 2]
    q0 = np.clip([*fl["dA"], fl["z0"], *fl["P"], fl["t1"], fl["zc"], *fl["dB"]], np.add(lo, 1e-6), np.subtract(hi, 1e-6))
    best = None
    for tstart in (q0[5], t10, 0.55 * Ttot, 0.75 * Ttot):     # a few starts: bounce timing is the multimodal part
        q0[5] = float(np.clip(tstart, lo[5] + 1e-3, hi[5] - 1e-3))
        sol = least_squares(res, q0, bounds=(lo, hi), loss="soft_l1", f_scale=1.5)
        if best is None or sol.cost < best.cost: best = sol
    q = best.x
    fl.update(dA=q[:2], z0=float(q[2]), P=q[3:5].copy(), t1=float(q[5]), zc=float(q[6]), dB=q[7:9].copy(), src="fit")
    return True

def median_err(fl, obs):
    if not obs: return None
    frs = sorted(obs); pr = fl_frame_px(fl, frs)
    return float(np.median(np.hypot(*(pr - np.array([obs[f] for f in frs])).T)))

# iteration 0: coarse candidates
obs_all = {}
e0 = []
for fl in flights:
    ob = coarse_obs(fl, lambda f, fl=fl: (70 + 0.6 * (f - fl["f"])) * SC)
    if ob: e0.append(median_err(fl, ob))
    if fit_pre(fl, ob):
        ob = coarse_obs(fl, 40 * SC); fit_pre(fl, ob)
    fit_post(fl, coarse_obs(fl, 40 * SC))
# iterations 1-2: guided detection around the current flights, then refit
for it, rad in enumerate((1.6, 0.9, 0.6)):
    found = guided(flights, rad)
    for fl in flights:
        ob = {f: q for (fid, f), q in found.items() if fid == id(fl)}
        cob = coarse_obs(fl, 25 * SC)
        for f, q in cob.items(): ob.setdefault(f, q)
        fl["obs"] = ob
        fit_joint(fl, ob)
    print(f"guided pass {it + 1}: ball found in {sum(len(fl['obs']) for fl in flights)} flight frames")

# ---- per-frame trace: model + residual correction snapped to observations ----
def build_trace(fl):
    frs = np.arange(fl["f"], fl_end(fl) + 1); m = fl_frame_px(fl, frs)
    ob = {f: q for f, q in fl.get("obs", {}).items() if fl["f"] < f < fl_end(fl)}
    res = {f: ob[f] - m[f - fl["f"]] for f in ob if np.hypot(*(ob[f] - m[f - fl["f"]])) < 0.35 * px_per_m(f, fl_court(fl, [f])[0]) + 12 * SC}
    # drop observations that jump away from their neighbours (noise on players/rackets), then smooth
    ks = sorted(res); clean = {}
    for i, f in enumerate(ks):
        nb = [res[g] for g in ks[max(0, i - 3):i + 4] if g != f and abs(g - f) <= 4]
        if len(nb) >= 2 and np.hypot(*(res[f] - np.median(nb, axis=0))) > 8 * SC + 0.25 * np.hypot(*res[f]): continue
        clean[f] = res[f]
    ks = sorted(clean)
    if len(ks) >= 3:
        arr = np.array([clean[f] for f in ks]); sm = np.c_[gaussian_filter1d(arr[:, 0], 0.8), gaussian_filter1d(arr[:, 1], 0.8)]
        clean = {f: v for f, v in zip(ks, sm)}
    res = clean
    keys = np.array(sorted(res)); out = m.copy()
    if len(keys):
        rv = np.array([res[k] for k in keys])
        for i, f in enumerate(frs):
            j = np.searchsorted(keys, f)
            lo_ = keys[j - 1] if j > 0 else None; hi_ = keys[j] if j < len(keys) else None
            if lo_ is not None and hi_ is not None and hi_ - lo_ <= 8:
                w = (f - lo_) / max(1, hi_ - lo_); r_ = (1 - w) * res[lo_] + w * res[hi_]
            else:
                near_k = lo_ if (hi_ is None or (lo_ is not None and f - lo_ < hi_ - f)) else hi_
                r_ = res[near_k] * np.exp(-abs(f - near_k) / 3.0)
            out[i] = m[i] + r_
    out[0] = m[0]
    return {int(f): [float(x), float(y)] for f, (x, y) in zip(frs, out)}

out = {"fps": FPS, "rallies": [], "track": track, "w": W, "h": H}
e1 = []
for ri, r in enumerate(p["rallies"]):
    shots = []
    for fl in [x for x in flights if x["r"] == ri]:
        A2 = fl["A"] + fl["dA"]; P2 = fl["P"]; t1 = fl["t1"]
        if fl.get("obs"): e1.append(median_err(fl, fl["obs"]))
        vh = np.linalg.norm(P2 - A2) / t1 * 1.08; vz = (-fl["z0"] + 0.5 * G * t1 * t1) / t1
        v0 = float(np.hypot(vh, vz)); dn = abs(P2[1] - NET_Y)
        res_ = "NET" if fl["end"] == "NET" else ("IN" if (1.32 <= P2[0] <= 9.65 and -0.05 <= P2[1] <= 23.82) else "OUT")
        if fl["end"] == "OUT": res_ = "OUT"
        s = {"n": fl["k"] + 1, "f": fl["f"], "who": fl["who"], "stroke": fl["st"], "A": A2.tolist(), "z0": fl["z0"], "P": P2.tolist(),
             "t1": t1, "fP": fl["f"] + t1 * FPS, "fNext": fl["f2"], "fEnd": fl_end(fl), "src": fl["src"], "n_obs": len(fl.get("obs", {})),
             "kmh": round(v0 * 3.6), "mph": round(v0 * 2.237), "depth": "DEEP" if dn > 8.3 else ("MID-COURT" if dn > 5.5 else "SHORT"),
             "res": res_, "trace": build_trace(fl)}
        shots.append(s)
        print(f"{r['name']:>12} {fl['f']:6d} {fl['who']:>2} {fl['st']:>6}  {s['kmh']:3d} km/h  {s['depth']:>9} {res_:>3}  "
              f"bounce ({P2[0]:4.1f},{P2[1]:5.1f})  {fl['src']:>10} ball seen in {s['n_obs']:2d} frames  err {median_err(fl, fl.get('obs', {})) or float('nan'):.1f}px")
    out["rallies"].append({**{k: v for k, v in r.items() if k != "shots"}, "shots": shots})
json.dump(out, open(work(p, "shots.json"), "w"))
tot = sum(s["fEnd"] - s["f"] for r in out["rallies"] for s in r["shots"]); seen = sum(s["n_obs"] for r in out["rallies"] for s in r["shots"])
print(f"\nball seen in {seen}/{tot} flight frames ({100 * seen / max(1, tot):.0f}%); model->ball error median "
      f"{np.median([e for e in e0 if e is not None]):.1f}px before fitting, {np.median([e for e in e1 if e is not None]):.1f}px after; "
      f"trace is snapped to the ball wherever it was seen")
