"""Contact sheets for reading the video (this is how shots get annotated).

usage:
  sheets.py project.json overview [step=10] [start] [end]       numbered grid of the whole court, every `step` frames
  sheets.py project.json near F1,F2,... [out]                     close-ups around the NEAR player at given frames
  sheets.py project.json far F1,F2,...  [out]                     crop of the far half (both far people) at given frames
  sheets.py project.json window CENTER [radius=33] [step=6] [near|far]   frames CENTER±radius as near/far crops
  sheets.py project.json full F1,F2,... [out]                     full frames, downscaled
Prints the path(s) of the written jpg(s). Frame numbers are burned into each tile (top-left, yellow).
"""
import sys, json
import numpy as np
from PIL import Image, ImageDraw
from common import load_project, work, frames

p = load_project(sys.argv[1]); mode = sys.argv[2]
tr = json.load(open(work(p, "track.json"))); W, H = tr["w"], tr["h"]; F = tr["frames"]
cal = json.load(open(work(p, "cam.json"))) if __import__("os").path.exists(work(p, "cam.json")) else None

def near_box(i):
    c = [b for b in F[i]["people"] if b[3] > 0.38 * H and b[4] > 0.4]
    if c: return max(c, key=lambda b: b[3] - b[1])
    for k in range(1, 40):
        for j in (i - k, i + k):
            if 0 <= j < len(F):
                c = [b for b in F[j]["people"] if b[3] > 0.38 * H and b[4] > 0.4]
                if c: return max(c, key=lambda b: b[3] - b[1])
    return [W / 2 - 50, H / 2 - 150, W / 2 + 50, H / 2 + 150]

def far_rect():
    if p.get("far_crop"): return p["far_crop"]
    if cal:
        import cv2
        Hc = np.array(cal["Hc"])
        q = cv2.perspectiveTransform(np.float32([[[-2, 20], [13, 20], [-2, 27], [13, 27]]]), Hc)[0]
        x0, x1 = q[:, 0].min(), q[:, 0].max(); yb = q[:, 1].max(); yt = q[:, 1].min()
        h = (yb - yt) * 4 + 0.1 * H
        return [int(max(0, x0)), int(max(0, yt - h * 0.75)), int(min(W, x1)), int(min(H, yb + h * 0.25))]
    return [int(W * 0.35), int(H * 0.18), int(W * 0.65), int(H * 0.33)]

def label(t, n):
    d = ImageDraw.Draw(t); d.rectangle([0, 0, 52, 15], fill="black"); d.text((3, 2), str(n), fill="yellow")

def tile_near(im, i, size=400):
    b = near_box(i); cx = (b[0] + b[2]) / 2; cy = (b[1] + b[3]) / 2; hh = (b[3] - b[1]) * 0.85 + 0.08 * H
    cx = min(max(cx, hh), W - hh); cy = min(max(cy, hh), H - hh)
    return im.crop((int(cx - hh), int(cy - hh), int(cx + hh), int(cy + hh))).resize((size, size))

def tile_far(im):
    x0, y0, x1, y1 = far_rect(); w = 720; h = int(w * (y1 - y0) / (x1 - x0))
    return im.crop((x0, y0, x1, y1)).resize((w, h), Image.LANCZOS)

def grid(tiles, cols, out):
    tw, th = tiles[0].size; rows = (len(tiles) + cols - 1) // cols
    sh = Image.new("RGB", (tw * cols, th * rows))
    for k, t in enumerate(tiles): sh.paste(t, ((k % cols) * tw, (k // cols) * th))
    sh.save(out, quality=85); print(out)

def grab(fr):
    return {i: Image.fromarray(f) for i, f in frames(p["video"], W, H, "rgb24", select=sorted(set(fr)))}

if mode == "overview":
    step = int(sys.argv[3]) if len(sys.argv) > 3 else 10
    a = int(sys.argv[4]) if len(sys.argv) > 4 else 0; b = int(sys.argv[5]) if len(sys.argv) > 5 else len(F) - 1
    fr = list(range(a, b + 1, step)); ims = grab(fr); per = 40
    for s in range(0, len(fr), per):
        ts = []
        for i in fr[s:s + per]:
            t = ims[i].resize((425, int(425 * H / W))); label(t, i); ts.append(t)
        grid(ts, 5, work(p, f"overview_{fr[s]:05d}.jpg"))
elif mode in ("near", "far", "full"):
    fr = [int(x) for x in sys.argv[3].split(",")]; ims = grab(fr)
    out = sys.argv[4] if len(sys.argv) > 4 else work(p, f"{mode}_{fr[0]}.jpg")
    ts = []
    for i in fr:
        t = tile_near(ims[i], i) if mode == "near" else tile_far(ims[i]) if mode == "far" else ims[i].resize((640, int(640 * H / W)))
        label(t, i); ts.append(t)
    grid(ts, 6 if mode == "near" else 3, out)
elif mode == "window":
    c = int(sys.argv[3]); rad = int(sys.argv[4]) if len(sys.argv) > 4 else 33; step = int(sys.argv[5]) if len(sys.argv) > 5 else 6
    side = sys.argv[6] if len(sys.argv) > 6 else "near"
    fr = [i for i in range(c - rad, c + rad + 1, step) if 0 <= i < len(F)]; ims = grab(fr); ts = []
    for i in fr:
        t = tile_near(ims[i], i) if side == "near" else tile_far(ims[i]); label(t, i); ts.append(t)
    grid(ts, 6 if side == "near" else 3, work(p, f"win_{side}_{c}.jpg"))
