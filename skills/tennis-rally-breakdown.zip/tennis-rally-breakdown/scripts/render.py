"""Render the vertical rally-breakdown video (1080x1920), SmartSwing-like layout.

usage:
  render.py project.json                 -> work/render_noaudio.mp4
  render.py project.json --preview F1,F2 -> work/prev_F.jpg for each frame (check these first!)
"""
import sys, json, math
import numpy as np, cv2
from PIL import Image, ImageDraw, ImageFont, ImageFilter
from scipy.ndimage import gaussian_filter1d
from common import load_project, work, frames, Geo, NET_Y, G
import subprocess

p = load_project(sys.argv[1])
PREVIEW = [int(x) for x in sys.argv[3].split(",")] if len(sys.argv) > 3 and sys.argv[2] == "--preview" else None
D = json.load(open(work(p, "shots.json"))); geo = Geo(p)
FPS = D["fps"]; W, H = D["w"], D["h"]; OW, OH = 1080, 1920
TR = D["track"]; PL = p["players"]; R = D["rallies"]
FOCUS = next(k for k, v in PL.items() if v["side"] == "near")
LANG = p.get("lang", "en")
N = len(geo.Hf)
F_START = p.get("trim", {}).get("start", max(0, R[0]["shots"][0]["f"] - int(2 * FPS)))
F_END = min(p.get("trim", {}).get("end", N - 1), N - 1)
FREEZE = int(p.get("summary_seconds", 3.5) * FPS)

T = {
 "en": dict(breakdown="RALLY BREAKDOWN", live="LIVE ANALYSIS", shotmap="SHOT MAP", shot="SHOT", speed="EST. SPEED", kmh="km/h",
            shots="SHOTS", rally="RALLY", fastest="FASTEST", fh="FH", bh="BH", volleys="VOLLEYS", serve="SERVE", seq="SHOT SEQUENCE",
            inflight="IN FLIGHT…", ready="READY", waiting="WAITING FOR FIRST SHOT", out="OUT", net="NET", winner="WINNER",
            deep="DEEP", mid="MID-COURT", short="SHORT", strokes={"FH": "FOREHAND", "BH": "BACKHAND", "SERVE": "SERVE", "VOLLEY": "VOLLEY", "SMASH": "SMASH", "LOB": "LOB", "SLICE": "SLICE", "DROP": "DROP SHOT"},
            summary="SESSION SUMMARY", rallies="RALLIES", won="WON", lost="LOST", n_shots="shots", vs="vs", avg="avg",
            takeaways="KEY TAKEAWAYS", allmap="SHOT MAP · ALL RALLIES", placement="PLACEMENT", session="Session", sec="s",
            in_pct="in"),
 "ru": dict(breakdown="РАЗБОР РОЗЫГРЫША", live="LIVE-АНАЛИЗ", shotmap="КАРТА УДАРОВ", shot="УДАР", speed="СКОРОСТЬ", kmh="км/ч",
            shots="УДАРЫ", rally="РОЗЫГРЫШ", fastest="МАКС.", fh="ФХ", bh="БХ", volleys="С ЛЁТА", serve="ПОДАЧА", seq="ПОСЛЕДОВАТЕЛЬНОСТЬ",
            inflight="В ПОЛЁТЕ…", ready="ГОТОВНОСТЬ", waiting="ЖДЁМ ПЕРВЫЙ УДАР", out="АУТ", net="СЕТКА", winner="ВИННЕР",
            deep="ГЛУБОКО", mid="СЕРЕДИНА", short="КОРОТКО", strokes={"FH": "ФОРХЕНД", "BH": "БЭКХЕНД", "SERVE": "ПОДАЧА", "VOLLEY": "С ЛЁТА", "SMASH": "СМЭШ", "LOB": "СВЕЧА", "SLICE": "СРЕЗКА", "DROP": "УКОРОЧЕННЫЙ"},
            summary="ИТОГИ СЕССИИ", rallies="РОЗЫГРЫШИ", won="ВЫИГРАН", lost="ПРОИГРАН", n_shots="ударов", vs="vs", avg="ср.",
            takeaways="ГЛАВНОЕ", allmap="КАРТА · ВСЕ РОЗЫГРЫШИ", placement="ПЛЕЙСМЕНТ", session="Сессия", sec="с", in_pct="в корт"),
}[LANG]
DEPTH = {"DEEP": T["deep"], "MID-COURT": T["mid"], "SHORT": T["short"]}
def stroke_name(s): return T["strokes"].get(s, s)

# ---------- fonts / colours ----------
SF = "/System/Library/Fonts/SFNS.ttf"
_fc = {}
WGT = {"reg": 400, "med": 510, "demi": 600, "bold": 700, "heavy": 860}
def F(size, w="bold", width=None):
    k = (size, w, width)
    if k not in _fc:
        f = ImageFont.truetype(SF, size)
        try: f.set_variation_by_axes([width or (72 if w in ("heavy", "bold") else 85), min(96, max(17, size)), 400, WGT[w]])
        except Exception: pass
        _fc[k] = f
    return _fc[k]
def hexc(s): s = s.lstrip("#"); return tuple(int(s[i:i + 2], 16) for i in (0, 2, 4))
BG = (11, 19, 33); CARD = (19, 31, 50); CARD2 = (25, 40, 63); LINE = (40, 58, 86)
LIME = (200, 255, 58); WHITE = (255, 255, 255); GRAY = (128, 141, 163); RED = (255, 66, 66); GREEN = (60, 230, 130)
COL = {k: hexc(v.get("color", "#40c8ff" if v["side"] == "near" else "#ff9a2e")) for k, v in PL.items()}
NAME = {k: v["name"] for k, v in PL.items()}
SHORT = {k: v.get("short", v["name"][:3]) for k, v in PL.items()}

def spaced(d, xy, text, font, fill, sp=2):
    x, y = xy
    for ch in text: d.text((x, y), ch, font=font, fill=fill); x += d.textlength(ch, font=font) + sp
    return x
def tw(d, t, f): return d.textlength(t, font=f)
def pill(d, x, y, text, font, fg, bg, pad=(10, 4), anchor="mm", border=None):
    w = d.textlength(text, font=font); h = font.size
    x0, y0 = (x - w / 2 - pad[0], y - h / 2 - pad[1]) if anchor == "mm" else (x, y)
    box = [x0, y0, x0 + w + 2 * pad[0], y0 + h + 2 * pad[1] + 2]
    d.rounded_rectangle(box, radius=(box[3] - box[1]) / 2, fill=bg, outline=border, width=2 if border else 0)
    d.text((box[0] + pad[0], box[1] + pad[1] - h * 0.1), text, font=font, fill=fg)

# ---------- crop / pan ----------
VY, VH = 170, 920
CH_ = int(p.get("crop_height_fraction", 0.93) * H); CW_ = int(CH_ * OW / VH)
if CW_ > W: CW_ = W; CH_ = int(W * VH / OW)
CY0 = int(min(max(0, p.get("crop_top_fraction", 0.07) * H), H - CH_))
fbox = np.array(TR[FOCUS]["box"]); fx = (fbox[:, 0] + fbox[:, 2]) / 2
cx0 = np.clip(gaussian_filter1d(0.6 * fx + 0.4 * W / 2, 25) - CW_ / 2, 0, W - CW_)
S = OW / CW_
def to_out(x, y, f): return ((x - cx0[f]) * S, (y - CY0) * S + VY)
def court_to_out(f, P3): return [to_out(x, y, f) for x, y in geo.court3_to_frame(f, P3)]

# ---------- ball model ----------
for r in R:
    for s in r["shots"]:
        t1 = s["t1"]; s["vz"] = (-s["z0"] + 0.5 * G * t1 * t1) / t1
        s["post"] = None
        if False: pass
        else:
            s["vz2"] = 0.55 * abs(s["vz"] - G * t1)
    r["f0"] = r["shots"][0]["f"]; r["fLast"] = r["shots"][-1]["fP"] + 8

def ball_at(s, f):
    tau = (f - s["f"]) / FPS; A = np.array(s["A"]); P = np.array(s["P"])
    if tau <= s["t1"]:
        return [*(A + (P - A) * tau / s["t1"]), max(0, s["z0"] + s["vz"] * tau - 0.5 * G * tau * tau)]
    t2 = tau - s["t1"]
    if s["post"]: h = P + (np.array(s["post"]["B"]) - P) * (t2 / s["post"]["t2"])
    else: h = P + (P - A) / s["t1"] * 0.62 * t2
    return [*h, max(0.0, s["vz2"] * t2 - 0.5 * G * t2 * t2)]

def trace_xy(s, t):
    """ball position in FRAME pixels at fractional frame t: fitted flight snapped to the detected ball"""
    tr = s["trace"]; a = int(np.floor(t)); b = a + 1; w = t - a
    pa = tr.get(str(a)) or tr.get(str(b)); pb = tr.get(str(b)) or pa
    return (1 - w) * pa[0] + w * pb[0], (1 - w) * pa[1] + w * pb[1]

def active(f):
    for r in R:
        for s in r["shots"]:
            if s["f"] <= f < s["fEnd"]: return s
def rally_at(f):
    cur = R[0]
    for r in R:
        if f >= r["f0"] - 2 * FPS: cur = r
    return cur

# ---------- video overlays ----------
def glow_line(img, pts, color, width):
    lay = Image.new("RGBA", img.size, (0, 0, 0, 0)); d = ImageDraw.Draw(lay); n = len(pts)
    for i in range(1, n): d.line([pts[i - 1], pts[i]], fill=color + (int(255 * (i / n) ** 1.3),), width=width)
    img.alpha_composite(lay.filter(ImageFilter.GaussianBlur(6))); img.alpha_composite(lay)

def head(who, f):
    b = TR[who]["box"][f]; return (b[0] + b[2]) / 2, b[1], b[3] - b[1]

def fade(lay, a):
    if a < 255: lay.putalpha(lay.getchannel("A").point(lambda v: v * a // 255))
    return lay

def draw_video(img, f):
    d = ImageDraw.Draw(img, "RGBA"); r = rally_at(f)
    for who in (FOCUS, r["opp"]):
        seen = TR[who]["seen"]
        if not any(seen[max(0, f - 6):f + 6]): continue
        x, y, h = head(who, f); ox, oy = to_out(x, y - 0.12 * h - 18, f)
        if 0 < ox < OW and VY + 15 < oy < VY + VH:
            pill(d, ox, oy, NAME[who], F(22, "bold"), COL[who], (10, 20, 36, 200), pad=(10, 3), border=COL[who] + (160,))
    for rr in R:
        for s in rr["shots"]:
            age = f - s["fP"]
            if 0 <= age < 22:
                rad = 0.25 + age * 0.04; a = int(230 * (1 - age / 22)); c = RED if s["res"] in ("OUT", "NET") else LIME
                ring = [[s["P"][0] + rad * math.cos(t), s["P"][1] + rad * math.sin(t), 0] for t in np.linspace(0, 2 * math.pi, 36)]
                pp = court_to_out(f, ring); d.line(pp + [pp[0]], fill=c + (a,), width=4)
                dot = [[s["P"][0] + .12 * math.cos(t), s["P"][1] + .12 * math.sin(t), 0] for t in np.linspace(0, 2 * math.pi, 20)]
                d.polygon(court_to_out(f, dot), fill=c + (a,))
    s = active(f)
    if s:
        ts = list(np.arange(max(s["f"], f - 9), f + 0.01, 0.34))
        if len(ts) >= 2:
            pp = [to_out(*trace_xy(s, t), f) for t in ts]; glow_line(img, pp, LIME, 7)
            d = ImageDraw.Draw(img, "RGBA"); hx, hy = pp[-1]
            d.ellipse([hx - 9, hy - 9, hx + 9, hy + 9], fill=LIME + (255,), outline=WHITE, width=2)
    for rr in R:
        for s in rr["shots"]:
            age = f - s["f"]
            if not 0 <= age < 45: continue
            x, y, h = head(s["who"], s["f"])
            if PL[s["who"]]["side"] == "near": ox, oy = to_out(x + (0.55 * h if x < W * 0.68 else -1.3 * h), y + 0.1 * h, f)
            else: ox, oy = to_out(x - 2.0 * h, y - 1.6 * h, f)
            a = int(255 * min(1, age / 4, (45 - age) / 8))
            lay = Image.new("RGBA", img.size, (0, 0, 0, 0)); ld = ImageDraw.Draw(lay)
            t1, t2 = stroke_name(s["stroke"]), f"~{s['kmh']} {T['kmh']}"
            w = max(tw(ld, t1, F(34, "heavy")), tw(ld, t2, F(24, "demi"))) + 30
            ox = min(max(ox, 10), OW - w - 10); oy = min(max(oy, VY + 10), VY + VH - 90)
            ld.rectangle([ox, oy, ox + w, oy + 74], fill=(10, 20, 36, 225)); ld.rectangle([ox, oy, ox + 5, oy + 74], fill=COL[s["who"]] + (255,))
            ld.text((ox + 16, oy + 2), t1, font=F(34, "heavy"), fill=COL[s["who"]]); ld.text((ox + 16, oy + 42), t2, font=F(24, "demi"), fill=WHITE)
            img.alpha_composite(fade(lay, a))

# ---------- panel ----------
MAP = (22, 1120, 352, 1890)
def map_xy(x, y):
    x0, y0, x1, y1 = MAP; sc = 19.5
    return (x0 + x1) / 2 + (x - 5.485) * sc, (y0 + y1) / 2 + 12 - (y - NET_Y) * sc

def draw_map(d, shots, r, summary=False, live=None):
    x0, y0, x1, y1 = MAP
    d.rounded_rectangle(MAP, 18, fill=(36, 92, 168)); d.rounded_rectangle([x0 + 6, y0 + 6, x1 - 6, y1 - 6], 14, fill=(52, 120, 205))
    a = map_xy(0, 0); b = map_xy(10.97, 23.77); d.rectangle([a[0], b[1], b[0], a[1]], fill=(66, 136, 222))
    for P_, Q in [((0, 0), (10.97, 0)), ((0, 23.77), (10.97, 23.77)), ((0, 0), (0, 23.77)), ((10.97, 0), (10.97, 23.77)),
                  ((1.37, 0), (1.37, 23.77)), ((9.6, 0), (9.6, 23.77)), ((1.37, 5.485), (9.6, 5.485)), ((1.37, 18.285), (9.6, 18.285)),
                  ((5.485, 5.485), (5.485, 18.285))]:
        d.line([map_xy(*P_), map_xy(*Q)], fill=(225, 238, 255), width=2)
    d.line([map_xy(-0.9, NET_Y), map_xy(11.87, NET_Y)], fill=(200, 210, 225), width=4)
    tc = (x0 + x1) / 2
    if summary: pill(d, tc, y0 + 34, f"{NAME[FOCUS]} · {T['placement']}", F(22, "bold"), COL[FOCUS], (10, 20, 36, 230))
    else:
        pill(d, tc, y0 + 34, NAME[r["opp"]], F(22, "bold"), COL[r["opp"]], (10, 20, 36, 230))
        pill(d, tc, y1 - 30, NAME[FOCUS], F(22, "bold"), COL[FOCUS], (10, 20, 36, 230))
    def clampm(q): return (min(max(q[0], x0 + 16), x1 - 16), min(max(q[1], y0 + 16), y1 - 16))
    for s in shots:
        c = COL[s["who"]]; A = clampm(map_xy(*s["A"]))
        if s.get("partial"): d.line([A, clampm(map_xy(*s["partial"]))], fill=c, width=4); continue
        Pp = clampm(map_xy(*s["P"])); d.line([A, Pp], fill=c, width=4 if not summary else 3)
        fill = RED if s["res"] in ("OUT", "NET") else c
        d.ellipse([Pp[0] - 13, Pp[1] - 13, Pp[0] + 13, Pp[1] + 13], fill=fill, outline=WHITE, width=2)
        lab = str(s["n"]) if not summary else stroke_name(s["stroke"])[0]
        d.text((Pp[0], Pp[1] - 1), lab, font=F(18, "heavy"), fill=(10, 20, 36), anchor="mm")
    for who, (px, py) in (live or {}).items():
        m = clampm(map_xy(px, py)); d.ellipse([m[0] - 7, m[1] - 7, m[0] + 7, m[1] + 7], fill=WHITE, outline=COL[who], width=3)

def status(s, f, last):
    if f < s["fP"]: return T["inflight"], GRAY
    if s["res"] == "OUT": return T["out"], RED
    if s["res"] == "NET": return T["net"], RED
    if last and R_END(s): return f"{T['winner']} · {DEPTH[s['depth']]}", GREEN
    return f"IN · {DEPTH[s['depth']]}", WHITE
def R_END(s):
    for r in R:
        if s is r["shots"][-1]: return r.get("end") == "WINNER"
    return False

def draw_panel(img, f):
    d = ImageDraw.Draw(img, "RGBA"); r = rally_at(f)
    d.rectangle([0, VY + VH, OW, OH], fill=BG); d.line([0, VY + VH, OW, VY + VH], fill=LINE, width=2)
    spaced(d, (24, VY + VH + 10), T["shotmap"], F(20, "demi"), GRAY, 3)
    done = [s for s in r["shots"] if s["f"] <= f]; cur = done[-1] if done else None
    shown = []
    for s in done:
        if f >= s["fP"]: shown.append(s)
        else: q = dict(s); q["partial"] = ball_at(s, f)[:2]; shown.append(q)
    live = {k: TR[k]["court"][f] for k in (FOCUS, r["opp"])}
    draw_map(d, shown, r, live=live)
    X0, X1 = 372, 1058; cy0, cy1 = 1120, 1340
    d.rounded_rectangle([X0, cy0, X1, cy1], 16, fill=CARD)
    if cur:
        c = COL[cur["who"]]; d.rectangle([X0, cy0 + 14, X0 + 6, cy1 - 14], fill=c)
        spaced(d, (X0 + 28, cy0 + 18), f"{T['shot']} {cur['n']}  ·  {NAME[cur['who']]}", F(26, "bold"), c, 2)
        d.text((X0 + 26, cy0 + 52), stroke_name(cur["stroke"]), font=F(74, "heavy", 70), fill=WHITE)
        st, sc = status(cur, f, cur is r["shots"][-1])
        pill(d, X0 + 28, cy0 + 164, st, F(22, "bold"), sc, CARD2, pad=(14, 5), anchor="lt")
        spaced(d, (X1 - 160, cy0 + 18), T["speed"], F(18, "demi"), GRAY, 2)
        sp = f"~{cur['kmh']}"; wsp = tw(d, sp, F(78, "heavy", 70))
        d.text((X1 - 96 - wsp, cy0 + 46), sp, font=F(78, "heavy", 70), fill=WHITE)
        d.text((X1 - 90, cy0 + 84), T["kmh"], font=F(28, "demi"), fill=WHITE)
        d.text((X1 - 24, cy0 + 152), f"{cur['mph']} mph", font=F(24, "med"), fill=GRAY, anchor="ra")
    else:
        spaced(d, (X0 + 28, cy0 + 18), r["name"], F(26, "bold"), COL[FOCUS], 2)
        d.text((X0 + 26, cy0 + 52), T["ready"], font=F(74, "heavy", 70), fill=WHITE)
        pill(d, X0 + 28, cy0 + 164, T["waiting"], F(22, "bold"), GRAY, CARD2, pad=(14, 5), anchor="lt")
    ty0, ty1 = 1356, 1476; gw = (X1 - X0 - 24) / 3
    rt = 0 if not done else (min(f, r["fLast"]) - r["f0"]) / FPS
    fast = max([s["kmh"] for s in done], default=0)
    for i, (lab, val, unit) in enumerate([(T["shots"], str(len(done)), ""), (T["rally"], f"{rt:.1f}", T["sec"]),
                                          (T["fastest"], str(fast) if fast else "–", T["kmh"] if fast else "")]):
        x = X0 + i * (gw + 12); d.rounded_rectangle([x, ty0, x + gw, ty1], 14, fill=CARD)
        spaced(d, (x + 18, ty0 + 12), lab, F(19, "demi"), GRAY, 2)
        d.text((x + 16, ty0 + 38), val, font=F(56, "heavy", 70), fill=WHITE)
        if unit: d.text((x + 24 + tw(d, val, F(56, "heavy", 70)), ty0 + 70), unit, font=F(22, "demi"), fill=GRAY)
    py0 = 1492; d.rounded_rectangle([X0, py0, X1, py0 + 130], 14, fill=CARD)
    for i, who in enumerate((FOCUS, r["opp"])):
        y = py0 + 20 + i * 54
        d.ellipse([X0 + 18, y + 12, X0 + 30, y + 24], fill=COL[who]); d.text((X0 + 40, y - 2), NAME[who], font=F(30, "heavy"), fill=COL[who])
        cnt = lambda k: sum(1 for s in done if s["who"] == who and s["stroke"] in k)
        x = X0 + 255
        for lab, v in ((T["fh"], cnt(("FH",))), (T["bh"], cnt(("BH", "SLICE"))), (T["volleys"], cnt(("VOLLEY",))), (T["serve"], cnt(("SERVE",)))):
            d.text((x, y + 5), lab, font=F(21, "demi"), fill=GRAY); x += tw(d, lab, F(21, "demi")) + 7
            d.text((x, y), str(v), font=F(28, "heavy"), fill=WHITE); x += tw(d, str(v), F(28, "heavy")) + 20
    sy0 = 1638; d.rounded_rectangle([X0, sy0, X1, 1890], 14, fill=CARD)
    spaced(d, (X0 + 20, sy0 + 12), T["seq"], F(19, "demi"), GRAY, 2); spaced(d, (X1 - 96, sy0 + 12), T["kmh"].upper(), F(19, "demi"), GRAY, 2)
    for i, s in enumerate(done[-5:]):
        y = sy0 + 44 + i * 40
        if s is cur: d.rounded_rectangle([X0 + 10, y - 3, X1 - 10, y + 35], 8, fill=CARD2)
        d.text((X0 + 22, y), str(s["n"]), font=F(28, "heavy"), fill=COL[s["who"]])
        d.text((X0 + 70, y), SHORT[s["who"]], font=F(28, "heavy"), fill=COL[s["who"]])
        d.text((X0 + 150, y), stroke_name(s["stroke"]), font=F(28, "demi"), fill=WHITE)
        if f >= s["fP"]:
            last = s is r["shots"][-1]
            st = T["out"] if s["res"] == "OUT" else T["net"] if s["res"] == "NET" else (T["winner"] if last and r.get("end") == "WINNER" else DEPTH[s["depth"]])
            d.text((X0 + 340, y + 3), st, font=F(22, "demi"), fill=RED if s["res"] in ("OUT", "NET") else GREEN if st == T["winner"] else GRAY)
        d.text((X1 - 26, y), f"~{s['kmh']}", font=F(28, "heavy"), fill=WHITE, anchor="ra")

def draw_header(img, f, r, summary=False):
    d = ImageDraw.Draw(img, "RGBA"); d.rectangle([0, 0, OW, VY], fill=BG)
    spaced(d, (24, 22), T["breakdown"], F(24, "bold"), COL[r["opp"]], 5)
    x = 22; d.text((x, 46), NAME[FOCUS], font=F(64, "heavy", 70), fill=COL[FOCUS]); x += tw(d, NAME[FOCUS], F(64, "heavy", 70)) + 14
    d.text((x, 66), T["vs"], font=F(38, "demi"), fill=GRAY); x += tw(d, T["vs"], F(38, "demi")) + 14
    d.text((x, 46), NAME[r["opp"]], font=F(64, "heavy", 70), fill=COL[r["opp"]])
    sub = p.get("venue", "")
    d.text((24, 126), (sub + " · " if sub else "") + (f"{T['session']} · {len(R)} {T['rallies'].lower()}" if summary else r["name"]), font=F(26, "med"), fill=GRAY)
    d.ellipse([OW - 222, 34, OW - 206, 50], fill=RED if (f // 15) % 2 == 0 else None, outline=RED, width=2)
    spaced(d, (OW - 196, 28), T["live"], F(24, "bold"), RED, 2)

# ---------- summary ----------
ALL = [s for r in R for s in r["shots"]]
MINE = [s for s in ALL if s["who"] == FOCUS]
def summary_lines():
    by = {}
    for s in MINE: by.setdefault(s["stroke"], []).append(s["kmh"])
    main = max(by, key=lambda k: len(by[k]))
    ins = [s for s in MINE if s["res"] == "IN"]
    lines = [ ("Главное оружие — " + stroke_name(main).lower() if LANG == "ru" else f"{stroke_name(main).title()} is the main weapon",
              f"{len(by[main])} {'из' if LANG == 'ru' else 'of'} {len(MINE)} {T['n_shots']}, {T['avg']} ~{round(np.mean(by[main]))} {T['kmh']}")]
    errs = [s for s in MINE if s["res"] in ("OUT", "NET")]
    if errs:
        e = errs[0]
        lines.append(("Ошибки" if LANG == "ru" else "Errors", f"{len(errs)} × {stroke_name(e['stroke']).lower()} — {T['out'].lower() if e['res']=='OUT' else T['net'].lower()}"))
    opp = [s for s in ALL if s["who"] != FOCUS]
    ofh = sum(1 for s in opp if s["stroke"] == "FH")
    if opp and ofh / len(opp) >= 0.65:
        lines.append(("Чаще в бэкхенд соперникам" if LANG == "ru" else "Aim more at the backhand",
                      f"{ofh} из {len(opp)} ответов соперников — форхенд" if LANG == "ru" else f"{ofh} of {len(opp)} rival returns were forehands"))
    fitted = [s for s in ins if s["src"] != "model"]
    if len(fitted) >= max(4, 0.5 * len(ins)):
        deep = sum(1 for s in fitted if s["depth"] == "DEEP")
        lines.append(("Глубина" if LANG == "ru" else "Depth",
                      f"{deep} из {len(fitted)} измеренных мячей — глубоко" if LANG == "ru" else f"{deep} of {len(fitted)} tracked balls landed deep"))
    return lines[:4]

def draw_summary(img, a):
    lay = Image.new("RGBA", img.size, (0, 0, 0, 0)); d = ImageDraw.Draw(lay)
    d.rectangle([0, VY, OW, VY + VH], fill=(8, 14, 26, 218))
    spaced(d, (60, VY + 50), T["summary"], F(28, "bold"), COL[R[-1]["opp"]], 5)
    d.text((56, VY + 84), NAME[FOCUS], font=F(110, "heavy", 70), fill=COL[FOCUS])
    inpct = round(100 * sum(1 for s in MINE if s["res"] == "IN") / max(1, len(MINE)))
    d.text((60, VY + 222), f"{len(MINE)} {T['n_shots']} · {len(R)} {T['rallies'].lower()} · {inpct}% {T['in_pct']}", font=F(40, "demi"), fill=WHITE)
    by = {}
    for s in MINE: by.setdefault(s["stroke"], []).append(s["kmh"])
    top = max(MINE, key=lambda s: s["kmh"])
    cards = [(stroke_name(k), str(len(v)), f"{T['avg']} ~{round(np.mean(v))} {T['kmh']}") for k, v in sorted(by.items(), key=lambda kv: -len(kv[1]))[:2]]
    cards.append((T["fastest"], str(top["kmh"]), f"{T['kmh']} · {stroke_name(top['stroke']).lower()}"))
    cw = (OW - 160) / 3
    for i, (lab, val, sub) in enumerate(cards):
        x = 60 + i * (cw + 20); y = VY + 300
        d.rounded_rectangle([x, y, x + cw, y + 200], 16, fill=CARD + (255,)); spaced(d, (x + 20, y + 16), lab, F(22, "demi"), GRAY, 2)
        d.text((x + 18, y + 46), val, font=F(92, "heavy", 70), fill=WHITE); d.text((x + 20, y + 156), sub, font=F(24, "med"), fill=GRAY)
    y = VY + 530; d.rounded_rectangle([60, y, OW - 60, y + 110 + 120 * min(len(R), 3)], 16, fill=CARD + (255,))
    spaced(d, (80, y + 18), T["rallies"], F(22, "demi"), GRAY, 2)
    for i, r in enumerate(R[:3]):
        yy = y + 60 + i * 120; dur = (r["fLast"] - r["f0"]) / FPS
        d.text((80, yy), f"{r['name']} · {T['vs']} {NAME[r['opp']]}", font=F(38, "heavy"), fill=WHITE)
        d.text((80, yy + 48), f"{len(r['shots'])} {T['n_shots']} · {dur:.1f} {T['sec']}" + (f" · {r['note']}" if r.get("note") else ""), font=F(28, "med"), fill=GRAY)
        wb = r.get("won_by")
        if wb: pill(d, OW - 150, yy + 36, T["won"] if wb == FOCUS else T["lost"], F(30, "heavy"), GREEN if wb == FOCUS else RED, CARD2, pad=(18, 6))
    img.alpha_composite(fade(lay, a))

def draw_summary_panel(img):
    d = ImageDraw.Draw(img, "RGBA"); d.rectangle([0, VY + VH, OW, OH], fill=BG)
    spaced(d, (24, VY + VH + 10), T["allmap"], F(20, "demi"), GRAY, 3)
    draw_map(d, MINE, R[-1], summary=True)
    X0, X1 = 372, 1058; d.rounded_rectangle([X0, 1120, X1, 1890], 16, fill=CARD)
    spaced(d, (X0 + 24, 1140), f"{NAME[FOCUS]} · {T['takeaways']}", F(24, "bold"), COL[FOCUS], 2)
    for i, (t, s) in enumerate(summary_lines()):
        y = 1200 + i * 165; d.rounded_rectangle([X0 + 20, y, X1 - 20, y + 140], 12, fill=CARD2)
        d.text((X0 + 40, y + 18), t, font=F(36, "heavy"), fill=WHITE); d.text((X0 + 40, y + 74), s, font=F(28, "med"), fill=GRAY)

# ---------- compose ----------
S_START = min(F_END, int(R[-1]["fLast"] + 25))
def compose(fr, f, freeze_k=None):
    x0 = int(cx0[f]); vid = cv2.resize(fr[CY0:CY0 + CH_, x0:x0 + CW_], (OW, VH), interpolation=cv2.INTER_AREA)
    img = Image.new("RGBA", (OW, OH), BG + (255,)); img.paste(Image.fromarray(vid), (0, VY)); r = rally_at(f)
    if freeze_k is None and f < S_START:
        draw_video(img, f); draw_header(img, f, r); draw_panel(img, f)
        for rr in R:
            t0 = F_START if rr is R[0] else rr["f0"] - 40; k = f - t0
            if 0 <= k < 40 and len(R) > 1:
                lay = Image.new("RGBA", img.size, (0, 0, 0, 0)); ld = ImageDraw.Draw(lay)
                ww = tw(ld, rr["name"], F(120, "heavy", 70)); ld.rectangle([0, VY + 360, OW, VY + 540], fill=(8, 14, 26, 190))
                ld.text(((OW - ww) / 2, VY + 372), rr["name"], font=F(120, "heavy", 70), fill=WHITE)
                img.alpha_composite(fade(lay, int(255 * min(1, k / 6, (40 - k) / 8))))
    else:
        draw_header(img, f, r, summary=True)
        k = (f - S_START) if freeze_k is None else (F_END - S_START + freeze_k)
        draw_summary(img, int(255 * min(1, k / 10))); draw_summary_panel(img)
    return np.asarray(img.convert("RGB"))

if PREVIEW:
    for f, fr in frames(p["video"], W, H, "rgb24", select=PREVIEW):
        out = work(p, f"prev_{f}.jpg"); Image.fromarray(compose(fr, f)).save(out, quality=88); print(out)
    sys.exit()
OUT = work(p, "render_noaudio.mp4")
enc = subprocess.Popen(["ffmpeg", "-v", "error", "-y", "-f", "rawvideo", "-pix_fmt", "rgb24", "-s", f"{OW}x{OH}", "-r", str(FPS), "-i", "-",
                        "-c:v", "libx264", "-preset", "medium", "-crf", "18", "-pix_fmt", "yuv420p", "-movflags", "+faststart", OUT], stdin=subprocess.PIPE)
last = None
for f, fr in frames(p["video"], W, H, "rgb24", select=list(range(F_START, F_END + 1))):
    enc.stdin.write(compose(fr, f).tobytes()); last = fr
    if f % 200 == 0: print("frame", f, flush=True)
for k in range(FREEZE): enc.stdin.write(compose(last, F_END, freeze_k=k).tobytes())
enc.stdin.close(); enc.wait()
print(OUT, f"start_sec={F_START / FPS:.3f}")
