"""Pass 1 over the video: camera motion (frame->reference homography), YOLO people + rackets.

usage: track.py project.json
writes work/track.json
"""
import sys, json
import numpy as np, cv2
from common import load_project, work, probe, frames

p = load_project(sys.argv[1])
W, H, FPS, _ = probe(p["video"])
from ultralytics import YOLO
import torch
dev = "mps" if torch.backends.mps.is_available() else ("cuda" if torch.cuda.is_available() else "cpu")
import os; model = YOLO(p.get("yolo_model", os.path.expanduser("~/.cache/tennis-rally-breakdown/yolo11m.pt")))

orb = cv2.ORB_create(3000); bf = cv2.BFMatcher(cv2.NORM_HAMMING, crossCheck=True)
bg_mask = np.zeros((H, W), np.uint8); bg_mask[: int(H * p.get("stabilize_top_fraction", 0.3))] = 255
ref = None; prevH = np.eye(3); out = []
for i, f in frames(p["video"], W, H, "bgr24"):
    g = cv2.cvtColor(f, cv2.COLOR_BGR2GRAY)
    kp, des = orb.detectAndCompute(g, bg_mask)
    Hr = prevH
    if ref is None:
        ref = (kp, des); Hr = np.eye(3)
    elif des is not None and len(kp) > 30:
        m = sorted(bf.match(des, ref[1]), key=lambda x: x.distance)[:600]
        if len(m) > 30:
            a = np.float32([kp[x.queryIdx].pt for x in m]); b = np.float32([ref[0][x.trainIdx].pt for x in m])
            Hh, inl = cv2.findHomography(a, b, cv2.RANSAC, 3.0)
            if Hh is not None and inl.sum() > 25: Hr = Hh
    prevH = Hr
    r = model.predict(f, classes=[0, 38], conf=0.15, verbose=False, imgsz=1280, device=dev)[0]
    people, rackets = [], []
    for bx, c, cl in zip(r.boxes.xyxy.cpu().numpy(), r.boxes.conf.cpu().numpy(), r.boxes.cls.cpu().numpy()):
        e = [round(float(v), 1) for v in bx] + [round(float(c), 3)]
        (people if cl == 0 else rackets).append(e)
    out.append({"H": Hr.tolist(), "people": people, "racket": rackets})
    if i % 200 == 0: print("frame", i, "people", len(people), flush=True)

json.dump({"w": W, "h": H, "fps": FPS, "frames": out}, open(work(p, "track.json"), "w"))
tx = [abs(x["H"][0][2]) + abs(x["H"][1][2]) for x in out]
print(f"done {len(out)} frames; max camera shift {max(tx):.1f}px")
