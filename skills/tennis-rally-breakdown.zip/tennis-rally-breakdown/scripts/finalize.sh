#!/bin/zsh
# Mux the source audio into the rendered video.  usage: finalize.sh project.json
set -e
PJ="$1"; DIR=$(cd "$(dirname "$PJ")" && pwd)
read VIDEO OUT WORK START <<< $(python3 - "$PJ" <<'EOF'
import json,sys,os
p=json.load(open(sys.argv[1])); d=os.path.dirname(os.path.abspath(sys.argv[1]))
w=os.path.join(d,p.get("workdir","work"))
tr=json.load(open(os.path.join(w,"track.json"))); sh=json.load(open(os.path.join(w,"shots.json")))
fps=tr["fps"]; st=p.get("trim",{}).get("start", max(0, sh["rallies"][0]["shots"][0]["f"]-int(2*fps)))
out=p.get("output", os.path.join(d,"rally_breakdown.mp4"))
print(p["video"].replace(" ","\\ "), out.replace(" ","\\ "), w.replace(" ","\\ "), st/fps)
EOF
)
R="$WORK/render_noaudio.mp4"
DUR=$(ffprobe -v error -show_entries format=duration -of csv=p=0 "$R")
# pick the first AAC audio stream if present (iPhone files also carry an APAC track that ffmpeg may not decode)
AIDX=$(ffprobe -v error -select_streams a -show_entries stream=index,codec_name -of csv=p=0 "$VIDEO" | awk -F, '$2=="aac"{print NR-1; exit}')
[ -z "$AIDX" ] && AIDX=0
if ffprobe -v error -select_streams a "$VIDEO" -show_entries stream=index -of csv=p=0 | grep -q .; then
  ffmpeg -v error -y -i "$R" -ss "$START" -i "$VIDEO" -map 0:v -map 1:a:$AIDX -c:v copy \
    -af "apad,afade=t=out:st=$(echo "$DUR-2.5" | bc):d=2.5" -c:a aac -b:a 160k -t "$DUR" -movflags +faststart "$OUT"
else
  cp "$R" "$OUT"
fi
echo "$OUT"
