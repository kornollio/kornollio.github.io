---
name: tennis-player-breakdown
description: Turns a handheld / gimbal (DJI Osmo Pocket, phone) vertical tennis video that follows ONE player from behind into a 1080×1920 stroke-analysis reel. The camera tracks and zooms on the player, draws a white pose skeleton and a yellow ball trail on real detections, and shows a dark "Clay" stats card (strokes, forehand/backhand split, est. shot speed, one bar chart of speed + stroke sequence) in Russian or English. Use it when the camera moves with the player (no fixed court view), for "разбери мои удары", "сделай как Rally AI / SwingVision", "видео с аналитикой форхендов и бэкхендов", "посчитай удары и скорость", or when someone sends a player-follow clip plus an example reel. For a static camera behind the baseline that shows both players and the whole court, use tennis-rally-breakdown instead.
---

# Tennis player breakdown (follow-cam)

Pipeline: pose + racket + ball detection → swing candidates → **confirm every stroke by eye** →
contact time from the racket sound → outgoing ball fit for speed → render the stats card → send.

Numbers on screen must be either verified (stroke count, FH/BH, timing) or measured with a stated
error (speed). Never fill a missing speed with a guess.

Scripts are in `scripts/`; each takes the path of `project.json` (schema: `references/project-schema.md`).
Python: a venv shared with tennis-rally-breakdown (same `~/.cache/tennis-rally-breakdown`), created by the bundled setup script:
```bash
PY=$(zsh ~/.claude/skills/tennis-player-breakdown/scripts/setup.sh)   # ~/.cache/tennis-rally-breakdown/venv/bin/python
cd ~/.claude/skills/tennis-player-breakdown/scripts
```
Weights go to `~/.cache/tennis-rally-breakdown/` (`yolo11m.pt`, `yolo11m-pose.pt`). If `yolo11m-pose.pt` is missing,
`$PY -c "from ultralytics import YOLO; YOLO('yolo11m-pose.pt')"` in that folder downloads it.

## 1. Look first
- `ffprobe` (resolution, fps, audio). DJI files have a 2nd low-res video stream — always use stream 0 (`-map 0:0`).
  OpenCV may decode fewer frames than `nb_frames` reports; frame indices everywhere are OpenCV's.
- Contact-sheet the video and the reference reel. Ask only what you can't see: the player's name for the plate,
  a social handle (or none), language (default: user's), whether to show speed at all.
- Do NOT copy another product's branding (logo, app name, @handle, outro). Put the user's own handle or nothing.
- Create `project.json` next to the video (`video`, `output`, `lang`, `name`, `handle`, `hand`, `style`).

## 2. Detection (background, ~4 min / 1000 frames of 4K-vertical on Apple Silicon)
```bash
$PY track.py project.json && $PY camaudio.py project.json
```
`camaudio.py` also prints loud audio transients — the player's own racket hits stand out (snr ≥ 6–40).

## 3. Strokes (the important part)
```bash
$PY swings.py project.json          # candidates + work/cand.jpg (player-cropped rows)
$PY sheet.py project.json 21,143,244   # exact-contact rows, -7..+6 frames
```
- Wrist-speed peaks include follow-throughs, take-backs and recoveries — about half are not shots. A shot has
  a ball near the racket and a finish over the opposite shoulder.
- From behind, right-hander: FH = take-back on image-right, finish over the left shoulder; BH = take-back on the
  left, finish to the right (one-handed BH finishes extended to the right). The backswing-side hint is only a hint.
- Check the gaps between candidates too, and the end of the clip (walking off with the racket is not a shot).
- Cross-check with the audio transients: a real contact has a loud transient within ~±5 frames.
- Write `shots: [[frame, "FH"|"BH"], ...]` (the visual contact frame). Tell the user the count and FH/BH split.

## 4. Analysis
```bash
$PY analyze.py project.json
```
Per shot: contact time from the audio peak, outgoing ball tracked from the racket (camera pan compensated),
then a perspective fit `u,v = f·(X,Y)/Z` with gravity; Z0 from the ball's size at contact (6.7 cm), `focal_px`
≈1700 for a 1728×3072 Osmo Pocket frame (scale with resolution / zoom).
- Expect only part of the shots to be measurable: during fast pans the ball smears into a 3–5 px dot.
  Fits are kept only with ≥ 8 points, median error ≤ 2.5 px, 15–180 km/h. The rest show "—".
- The bracket column (Z0 ±15–20%) is the honest error: about ±25%. Say so to the user and on screen ("≈", "±25%").
- If a value looks wrong after you check the frames, set `speed_override: {"<frame>": null}` — don't tweak numbers.
- Audio-only timing of the opponent's hits does not work reliably (other courts, footsteps) — don't rely on it.

## 5. Preview, render
```bash
$PY render.py project.json --preview 230,520,725,912   # work/prev_<f>.jpg
$PY render.py project.json                             # writes project["output"] with the source audio
```
Check the previews: the skeleton on the body, the trail on the real ball, nothing under the card covers the feet
(follow-cam keeps the player centre at 40% of the frame height), Cyrillic renders (no boxes).
Then contact-sheet the final file (`ffmpeg -vf fps=1,scale=180:-1,tile=13x3`) to confirm the counters step at each contact.

## Styles
`style`: `clay` (default — dark glass card, FH ball-yellow / BH clay-orange, one chart of speed + stroke sequence),
`broadcast` (TV scoreboard band with the name block), `minimal` (white floating cards + rally timeline).
When the user wants a different look, render one frame in 2–3 styles side by side and let them pick.
Labels: `lang` = `ru` | `en`. Avenir Next has no Cyrillic — Russian labels use Helvetica Neue Condensed (handled in `styles.py`).

## Report
Separate in the final message: verified (strokes, FH/BH, timing, frame by frame + audio) vs measured with error
(speeds: which shots, ≈ values, ±25%, why the others are "—").
