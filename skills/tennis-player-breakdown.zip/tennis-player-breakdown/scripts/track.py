# pose (YOLO11-pose) + racket/ball (YOLO11 det) per frame for the followed player -> work/pose.json
# usage: track.py project.json        (~4 min per 1000 frames of 4K-vertical on Apple Silicon)
import numpy as np, os
from ultralytics import YOLO
from common import *
P = load()
pose = YOLO(os.path.join(CACHE, "yolo11m-pose.pt")); det = YOLO(os.path.join(CACHE, "yolo11m.pt"))
cap = cv2.VideoCapture(P["_video"]); n = int(cap.get(7)); out = []; prev = None; i = 0
while True:
    ok, fr = cap.read()
    if not ok: break
    H, Wd = fr.shape[:2]
    r = pose.predict(fr, imgsz=1280, conf=0.25, verbose=False, device="mps")[0]
    best = None
    if r.boxes is not None and len(r.boxes):
        bx = r.boxes.xyxy.cpu().numpy(); kp = r.keypoints.data.cpu().numpy(); sc = []
        for b in bx:   # biggest + most central person, continuous with the previous frame
            cx = (b[0] + b[2]) / 2; area = (b[2] - b[0]) * (b[3] - b[1])
            s = area / (Wd * H) * 10 - abs(cx - Wd / 2) / Wd
            if prev is not None: s -= np.hypot(cx - prev[0], (b[1] + b[3]) / 2 - prev[1]) / Wd * 3
            sc.append(s)
        k = int(np.argmax(sc)); best = {"box": bx[k].round(1).tolist(), "kp": kp[k].round(2).tolist()}
        prev = ((bx[k][0] + bx[k][2]) / 2, (bx[k][1] + bx[k][3]) / 2)
    elif out and out[-1]["p"]: best = out[-1]["p"]          # hold last pose if the player is lost for a frame
    d = det.predict(fr, imgsz=1280, conf=0.12, classes=[38, 32], verbose=False, device="mps")[0]
    rk, bl = [], []
    for b, c, cf in zip(d.boxes.xyxy.cpu().numpy(), d.boxes.cls.cpu().numpy(), d.boxes.conf.cpu().numpy()):
        (rk if int(c) == 38 else bl).append(b.round(1).tolist() + [round(float(cf), 3)])
    out.append({"f": i, "p": best, "racket": rk, "ball": bl}); i += 1
    if i % 100 == 0: print(i, n, flush=True)
jsave(P, "pose.json", {"W": Wd, "H": H, "frames": out})
print("done", i, "frames; pose found in", sum(1 for f in out if f["p"]), )
