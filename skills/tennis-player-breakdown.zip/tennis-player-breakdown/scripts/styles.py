# Stats-panel styles (clay = default, broadcast, minimal), labels in en/ru. build(style, k, shots, P) -> RGBA 1080x1920 overlay (k = shots done)
from PIL import Image, ImageDraw, ImageFilter, ImageFont

OW, OH = 1080, 1920
COND = "/System/Library/Fonts/Avenir Next Condensed.ttc"
AVN = "/System/Library/Fonts/Avenir Next.ttc"
RND = "/System/Library/Fonts/SFNSRounded.ttf"
def cond(s, w="Bold"): return ImageFont.truetype(COND, s, index={"Bold": 0, "Demi": 2, "Medium": 5, "Regular": 7, "Heavy": 8}[w])
def avn(s, w="Bold"): return ImageFont.truetype(AVN, s, index={"Bold": 0, "Demi": 2, "Medium": 5, "Regular": 7, "Heavy": 8}[w])
def rnd(s, w="Bold"):
    f = ImageFont.truetype(RND, s); f.set_variation_by_name(w); return f

HNC = "/System/Library/Fonts/HelveticaNeue.ttc"      # has Cyrillic; Avenir Next has not
T = {"en": dict(strokes="STROKES", fh="FOREHAND", bh="BACKHAND", speed="SHOT SPEED", kmh="km/h", peak="peak", FH="FH", BH="BH",
                stroke="STROKE", of="of", count="COUNT", avg="AVG SPEED", note="speeds ≈ ±25%", rally="Rally",
                strokes_t="Strokes", fhbh_t="Forehand / Backhand", speed_t="Shot speed", fh_t="Forehand", bh_t="Backhand"),
     "ru": dict(strokes="УДАРЫ", fh="ФОРХЕНД", bh="БЭКХЕНД", speed="СКОРОСТЬ", kmh="км/ч", peak="пик", FH="ФХ", BH="БХ",
                stroke="УДАР", of="из", count="КОЛ-ВО", avg="СР. СКОРОСТЬ", note="скорость ≈ ±25%", rally="Розыгрыш",
                strokes_t="Удары", fhbh_t="Форхенд / Бэкхенд", speed_t="Скорость", fh_t="Форхенд", bh_t="Бэкхенд")}
LANG = "en"
def tr(k): return T[LANG][k]
def lab(s, w="Demi"):
    """label font: Avenir Next Condensed for latin, Helvetica Neue Condensed for Cyrillic"""
    if LANG == "en": return cond(s, w)
    return ImageFont.truetype(HNC, s, index=9 if w in ("Heavy", "Bold") else 4)
def lab_r(s, w="Semibold"):
    return rnd(s, w)   # SF Rounded has Cyrillic

def stats(k, shots):
    done = shots[:k]; sp = [s["speed"] for s in done if s["speed"] is not None]
    avg = lambda xs: round(sum(xs) / len(xs)) if xs else None
    return dict(done=done, fh=sum(s["stroke"] == "FH" for s in done), bh=sum(s["stroke"] == "BH" for s in done),
                cur=done[-1]["speed"] if k else None, peak=max(sp) if sp else None,
                fha=avg([s["speed"] for s in done if s["stroke"] == "FH" and s["speed"] is not None]),
                bha=avg([s["speed"] for s in done if s["stroke"] == "BH" and s["speed"] is not None]))
def ap(v): return "≈%d" % v if v is not None else "—"

def spaced(d, xy, text, font, fill, sp=3, anchor="ls"):
    x, y = xy
    if anchor[0] == "r": x -= sum(d.textlength(c, font=font) + sp for c in text) - sp
    for c in text:
        d.text((x, y), c, font=font, fill=fill, anchor="l" + anchor[1]); x += d.textlength(c, font=font) + sp

# ------------------------------------------------------------------ 1. CLAY — dark glass card, clay + ball-yellow
def clay(k, shots, P):
    S = stats(k, shots); N = len(shots)
    YEL, CLAY, WH, MUT = (217, 242, 75), (232, 110, 62), (255, 255, 255), (150, 150, 155)
    im = Image.new("RGBA", (OW, OH), (0, 0, 0, 0))
    sh = Image.new("RGBA", (OW, OH), (0, 0, 0, 0)); ImageDraw.Draw(sh).rounded_rectangle([28, 1418, 1052, 1892], 44, fill=(0, 0, 0, 120))
    im.alpha_composite(sh.filter(ImageFilter.GaussianBlur(18)))
    d = ImageDraw.Draw(im)
    d.rounded_rectangle([28, 1410, 1052, 1884], 44, fill=(17, 17, 20, 218))
    L = lab(22, "Demi")
    # strokes
    spaced(d, (74, 1468), tr("strokes"), L, MUT)
    d.text((70, 1592), str(k), font=cond(118, "Bold"), fill=WH, anchor="ls")
    d.text((70 + d.textlength(str(k), font=cond(118)) + 8, 1592), "/%d" % N, font=cond(40, "Demi"), fill=MUT, anchor="ls")
    # FH / BH with split bar
    lx = 330
    for txt, col in ((tr("fh"), YEL), (" · ", MUT), (tr("bh"), CLAY)):
        spaced(d, (lx, 1468), txt, L, col); lx += sum(d.textlength(ch, font=L) + 3 for ch in txt)
    f = cond(118); x = 330
    d.text((x, 1592), str(S["fh"]), font=f, fill=YEL, anchor="ls"); x += d.textlength(str(S["fh"]), font=f) + 22
    d.text((x, 1580), "·", font=cond(70), fill=MUT, anchor="ls"); x += 42
    d.text((x, 1592), str(S["bh"]), font=f, fill=CLAY, anchor="ls")
    bw = 300; d.rounded_rectangle([330, 1614, 330 + bw, 1624], 5, fill=(55, 55, 60))
    if k:
        fw = bw * S["fh"] / k
        if S["bh"]: d.rounded_rectangle([330, 1614, 330 + bw, 1624], 5, fill=CLAY)
        if S["fh"]: d.rounded_rectangle([330, 1614, 330 + fw, 1624], 5, fill=YEL)
    # speed
    spaced(d, (720, 1468), tr("speed"), L, MUT)
    big = ap(S["cur"]) if k else "—"
    d.text((716, 1592), big, font=cond(118), fill=WH, anchor="ls")
    d.text((716 + d.textlength(big, font=cond(118)) + 10, 1592), tr("kmh"), font=lab(30, "Demi"), fill=MUT, anchor="ls")
    d.text((720, 1626), "%s %s · ±25%%" % (tr("peak"), ap(S["peak"])), font=lab(24, "Medium"), fill=MUT, anchor="ls")
    d.line([70, 1660, 1010, 1660], fill=(60, 60, 66), width=2)
    # combined speed + sequence chart
    x0, x1, base, top = 70, 1010, 1810, 1700; cw = (x1 - x0) / N; vmax = 90
    for j, s in enumerate(shots):
        cx = x0 + cw * (j + 0.5); bw2 = cw * 0.62
        col = YEL if s["stroke"] == "FH" else CLAY
        if j >= k:
            d.rounded_rectangle([cx - bw2 / 2, base - 10, cx + bw2 / 2, base], 5, outline=(70, 70, 76), width=2)
            d.text((cx, base + 34), str(j + 1), font=cond(24, "Demi"), fill=(90, 90, 96), anchor="ms"); continue
        cur = j == k - 1; alpha = 255 if cur else 175
        if s["speed"] is None:
            d.rounded_rectangle([cx - bw2 / 2, base - 10, cx + bw2 / 2, base], 5, fill=col[:3] + (alpha,))
            d.text((cx, base - 20), "—", font=cond(26, "Demi"), fill=MUT, anchor="ms")
        else:
            h = (base - top) * min(s["speed"], vmax) / vmax
            d.rounded_rectangle([cx - bw2 / 2, base - h, cx + bw2 / 2, base], 10, fill=col[:3] + (alpha,))
            d.text((cx, base - h - 10), str(s["speed"]), font=cond(26, "Bold"), fill=WH if cur else MUT, anchor="ms")
        if cur: d.rounded_rectangle([cx - bw2 / 2 - 5, base + 8, cx + bw2 / 2 + 5, base + 44], 18, fill=col)
        d.text((cx, base + 34), tr(s["stroke"]), font=lab(24, "Bold"), fill=(20, 20, 22) if cur else col, anchor="ms")
    return im

# ------------------------------------------------------------------ 2. BROADCAST — TV scoreboard band
def broadcast(k, shots, P):
    S = stats(k, shots); N = len(shots)
    NAVY, NAVY2, LIME, WH, MUT = (13, 24, 44), (24, 40, 68), (198, 244, 50), (255, 255, 255), (140, 156, 180)
    im = Image.new("RGBA", (OW, OH), (0, 0, 0, 0)); d = ImageDraw.Draw(im)
    Y = 1468
    d.rectangle([0, Y, OW, OH], fill=NAVY + (238,)); d.rectangle([0, Y, OW, Y + 7], fill=LIME)
    # name block
    d.rectangle([0, Y + 7, 330, Y + 120], fill=LIME)
    d.text((40, Y + 82), P["name"].upper(), font=ImageFont.truetype("/System/Library/Fonts/HelveticaNeue.ttc", 54, index=9), fill=NAVY, anchor="ls")
    d.text((350, Y + 60), tr("stroke"), font=lab(26, "Demi"), fill=MUT, anchor="ls")
    d.text((350, Y + 104), "%d" % k, font=cond(56, "Heavy"), fill=WH, anchor="ls")
    d.text((350 + d.textlength(str(k), font=cond(56, "Heavy")) + 6, Y + 104), "%s %d" % (tr("of"), N), font=lab(30, "Demi"), fill=MUT, anchor="ls")
    d.text((1040, Y + 60), "%s  %s" % (tr("speed"), tr("kmh")), font=lab(26, "Demi"), fill=MUT, anchor="rs")
    d.text((1040, Y + 104), ap(S["cur"]) if k else "—", font=cond(56, "Heavy"), fill=LIME, anchor="rs")
    # table
    rows = [(tr("fh"), S["fh"], S["fha"]), (tr("bh"), S["bh"], S["bha"])]
    ty = Y + 150
    d.text((40, ty), "", font=cond(24))
    d.text((600, ty + 4), tr("count"), font=lab(24, "Demi"), fill=MUT, anchor="ms"); d.text((850, ty + 4), tr("avg"), font=lab(24, "Demi"), fill=MUT, anchor="ms")
    for r, (nm, c, a) in enumerate(rows):
        y = ty + 20 + r * 62
        d.rectangle([24, y, OW - 24, y + 54], fill=NAVY2 + (255,) if r == 0 else NAVY + (0,))
        d.rectangle([24, y, 32, y + 54], fill=LIME if r == 0 else WH)
        d.text((52, y + 40), nm, font=lab(36, "Bold"), fill=WH, anchor="ls")
        d.text((600, y + 42), str(c), font=cond(42, "Heavy"), fill=WH, anchor="ms")
        d.text((850, y + 42), ap(a), font=cond(42, "Heavy"), fill=WH, anchor="ms")
    d.text((OW - 30, ty + 160), "%s %s · %s" % (tr("peak"), ap(S["peak"]), tr("note")), font=lab(22, "Medium"), fill=MUT, anchor="rs")
    # sequence strip
    sy = OH - 92; sw = (OW - 80) / N
    for j, s in enumerate(shots):
        x = 40 + j * sw
        if j < k:
            fill = LIME if s["stroke"] == "FH" else WH
            d.rectangle([x + 4, sy, x + sw - 4, sy + 58], fill=fill)
            d.text((x + sw / 2, sy + 42), tr(s["stroke"]), font=lab(30, "Heavy"), fill=NAVY, anchor="ms")
            if j == k - 1: d.rectangle([x, sy - 4, x + sw, sy + 62], outline=WH, width=3)
        else:
            d.rectangle([x + 4, sy, x + sw - 4, sy + 58], outline=NAVY2, width=3)
            d.text((x + sw / 2, sy + 40), str(j + 1), font=cond(26, "Demi"), fill=(70, 86, 112), anchor="ms")
    return im

# ------------------------------------------------------------------ 3. MINIMAL — floating light cards over full-screen video
def minimal(k, shots, P):
    S = stats(k, shots); N = len(shots)
    INK, MUT, FHC, BHC = (20, 22, 26), (128, 132, 140), (34, 139, 94), (232, 120, 60)
    im = Image.new("RGBA", (OW, OH), (0, 0, 0, 0))
    cards = [(32, 1440, 360, 1640), (376, 1440, 704, 1640), (720, 1440, 1048, 1640), (32, 1660, 1048, 1880)]
    sh = Image.new("RGBA", (OW, OH), (0, 0, 0, 0)); sd = ImageDraw.Draw(sh)
    for c in cards: sd.rounded_rectangle([c[0], c[1] + 10, c[2], c[3] + 10], 34, fill=(0, 0, 0, 90))
    im.alpha_composite(sh.filter(ImageFilter.GaussianBlur(16))); d = ImageDraw.Draw(im)
    for c in cards: d.rounded_rectangle(c, 34, fill=(255, 255, 255, 236))
    lab = rnd(24, "Semibold"); big = rnd(84, "Bold")
    d.text((64, 1494), tr("strokes_t"), font=lab, fill=MUT, anchor="ls")
    d.text((62, 1600), str(k), font=big, fill=INK, anchor="ls")
    d.text((408, 1494), tr("fhbh_t"), font=lab, fill=MUT, anchor="ls")
    x = 406; d.text((x, 1600), str(S["fh"]), font=big, fill=FHC, anchor="ls"); x += d.textlength(str(S["fh"]), font=big) + 10
    d.text((x, 1600), "/", font=rnd(60, "Medium"), fill=(200, 202, 206), anchor="ls"); x += 34
    d.text((x, 1600), str(S["bh"]), font=big, fill=BHC, anchor="ls")
    d.text((752, 1494), tr("speed_t"), font=lab, fill=MUT, anchor="ls")
    t = ap(S["cur"]) if k else "—"
    d.text((750, 1600), t, font=big, fill=INK, anchor="ls")
    d.text((750 + d.textlength(t, font=big) + 8, 1600), tr("kmh"), font=rnd(26, "Semibold"), fill=MUT, anchor="ls")
    d.text((752, 1626), "%s %s · ±25%%" % (tr("peak"), ap(S["peak"])), font=rnd(20, "Medium"), fill=MUT, anchor="ls")
    # timeline
    d.text((64, 1714), tr("rally"), font=lab, fill=MUT, anchor="ls")
    lx0, lx1, ly = 90, 990, 1800; step = (lx1 - lx0) / (N - 1)
    bl = "● " + tr("bh_t"); d.text((1016, 1714), bl, font=rnd(20, "Semibold"), fill=BHC, anchor="rs")
    d.text((1016 - d.textlength(bl, font=rnd(20, "Semibold")) - 20, 1714), "● " + tr("fh_t"), font=rnd(20, "Semibold"), fill=FHC, anchor="rs")
    d.line([lx0, ly, lx1, ly], fill=(226, 228, 232), width=6)
    if k > 1: d.line([lx0, ly, lx0 + step * (k - 1), ly], fill=(60, 64, 72), width=6)
    for j, s in enumerate(shots):
        x = lx0 + step * j; col = FHC if s["stroke"] == "FH" else BHC
        if j >= k:
            d.ellipse([x - 12, ly - 12, x + 12, ly + 12], fill=(255, 255, 255), outline=(210, 212, 216), width=4); continue
        r = 22 if j == k - 1 else 17
        if j == k - 1: d.ellipse([x - r - 9, ly - r - 9, x + r + 9, ly + r + 9], fill=col[:3] + (60,))
        d.ellipse([x - r, ly - r, x + r, ly + r], fill=col)
        d.text((x, ly + 9), tr(s["stroke"])[0], font=rnd(22, "Bold"), fill=(255, 255, 255), anchor="ms")
        d.text((x, ly - 36), str(s["speed"]) if s["speed"] is not None else "—", font=rnd(22, "Semibold"), fill=INK if j == k - 1 else MUT, anchor="ms")
        d.text((x, ly + 62), str(j + 1), font=rnd(20, "Medium"), fill=MUT, anchor="ms")
    return im

def build(style, k, shots, P):
    global LANG; LANG = P.get("lang", "en")
    return {"clay": clay, "broadcast": broadcast, "minimal": minimal}[style](k, shots, P)
