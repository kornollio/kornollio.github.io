#!/bin/zsh
# Creates (once) the Python env used by all scripts: ~/.cache/tennis-rally-breakdown/venv
# prints the python path to use.
set -e
V=~/.cache/tennis-rally-breakdown/venv
if [ ! -x "$V/bin/python" ]; then
  mkdir -p ~/.cache/tennis-rally-breakdown
  if command -v uv >/dev/null; then
    uv venv -q -p 3.12 "$V" 2>/dev/null || uv venv -q "$V"
    uv pip install -q -p "$V/bin/python" ultralytics opencv-python numpy pillow scipy
  else
    python3 -m venv "$V"; "$V/bin/pip" install -q ultralytics opencv-python numpy pillow scipy
  fi
fi
command -v ffmpeg >/dev/null || { echo "ffmpeg missing: brew install ffmpeg" >&2; exit 1; }
"$V/bin/python" -c "import ultralytics, cv2, scipy, PIL" && echo "$V/bin/python"
