# player-cropped contact sheets.  usage: sheet.py project.json f1,f2,... [before after step]
# one row per frame in the list, frames f-before..f+after; default -7..+6 step 1 (exact contact frame)
import sys
from PIL import Image, ImageDraw, ImageFont
from common import *
def crops(P, out, cands, a=-7, b=6, step=1, tw=150, th=125):
    D = jload(P, "pose.json")["frames"]; n = len(D)
    need = sorted({f for c in cands for f in range(c + a, c + b, step) if 0 <= f < n}); fr = {}
    cap = cv2.VideoCapture(P["_video"]); i = 0
    while need and i <= need[-1]:
        ok, im = cap.read()
        if not ok: break
        if i in need: fr[i] = im
        i += 1
    font = ImageFont.truetype("/System/Library/Fonts/Helvetica.ttc", 20); rows = []
    for c in cands:
        row = []
        for f in range(c + a, c + b, step):
            if f not in fr or not D[f]["p"]: continue
            x0_, y0_, x1_, y1_ = D[f]["p"]["box"]; cx = (x0_ + x1_) / 2; cy = (y0_ + y1_) / 2; h = (y1_ - y0_) * 1.5
            H, Wd = fr[f].shape[:2]
            crop = fr[f][int(max(0, cy - h / 2)):int(min(H, cy + h / 2)), int(max(0, cx - h * .6)):int(min(Wd, cx + h * .6))]
            im = Image.fromarray(cv2.cvtColor(crop, cv2.COLOR_BGR2RGB)).resize((tw, th))
            ImageDraw.Draw(im).text((3, 2), str(f), fill=(255, 0, 255) if f == c else (255, 255, 0), font=font); row.append(im)
        rows.append(row)
    sh = Image.new("RGB", (tw * max(len(r) for r in rows), th * len(rows)))
    for j, r in enumerate(rows):
        for k, im in enumerate(r): sh.paste(im, (k * tw, j * th))
    sh.save(out, quality=88)
if __name__ == "__main__":
    P = load(); cs = [int(x) for x in sys.argv[2].split(",")]
    a, b, s = (int(sys.argv[3]), int(sys.argv[4]), int(sys.argv[5])) if len(sys.argv) > 5 else (-7, 7, 1)
    out = W(P, "sheet_%s.jpg" % cs[0]); crops(P, out, cs, a, b, s); print(out)
