# smoothing + follow-cam data, contact time from the racket sound, outgoing ball tracks and shot-speed fits
# usage: analyze.py project.json       -> work/analysis.json, prints a per-shot table
import numpy as np
from scipy.ndimage import gaussian_filter1d
from scipy.optimize import least_squares
from common import *
P = load(); D = jload(P, "pose.json"); F = D["frames"]; n = len(F); SW, SH = D["W"], D["H"]
cam = np.array(jload(P, "cam.json")); env = np.load(W(P, "env.npy")); FPS = P["_fps"]
f_px = float(P.get("focal_px", 1700)); g = 9.81; BALL = 0.067; wi = 10 if P.get("hand", "R") == "R" else 9
# ---- skeleton smoothing (confidence-weighted)
K = np.array([f["p"]["kp"] for f in F], dtype=float)
for j in range(17):
    c = K[:, j, 2]
    for d in range(2): K[:, j, d] = gaussian_filter1d(K[:, j, d] * c, 1.0) / np.maximum(gaussian_filter1d(c, 1.0), 1e-3)
B = np.array([f["p"]["box"] for f in F], dtype=float)
pc = np.c_[gaussian_filter1d((B[:, 0] + B[:, 2]) / 2, 12), gaussian_filter1d((B[:, 1] + B[:, 3]) / 2, 12), gaussian_filter1d(B[:, 3] - B[:, 1], 20)]
# ---- contact time from audio (own hits are the loudest transients)
def t_audio(c):
    a = int((c - 4) / FPS * 1000); b = int((c + 6) / FPS * 1000); seg = env[a:b]
    if not len(seg): return c, 0
    k = int(np.argmax(seg)); return (a + k) / 1000 * FPS, seg[k] / np.median(env[max(0, a - 500):b + 500])
def dets(i, cam0, th):
    return [((b[0] + b[2]) / 2 - (cam[i, 0] - cam0[0]), (b[1] + b[3]) / 2 - (cam[i, 1] - cam0[1]), min(b[2] - b[0], b[3] - b[1]), b[4])
            for b in F[i]["ball"] if b[4] >= th and b[2] - b[0] < 70]
def fit(t, u, v, Z0):
    def r(p):
        X0, Y0, vx, vy, vz = p; Z = Z0 + vz * t
        return np.r_[f_px * (X0 + vx * t) / Z - u, f_px * (Y0 + vy * t + g * t * t / 2) / Z - v]
    s = least_squares(r, [u[0] * Z0 / f_px, v[0] * Z0 / f_px, 0, -3, 15], bounds=([-20, -20, -30, -25, 0], [20, 20, 30, 25, 45]), loss="soft_l1", f_scale=3)
    return s.x, float(np.median(np.abs(s.fun)))
def outgoing(c, t0):
    cam0 = cam[c]; wr = K[c, wi, :2]; best = None
    for s0 in range(int(np.floor(t0)), int(t0) + 5):
        for d in dets(s0, cam0, 0.3):
            if np.hypot(d[0] - wr[0], d[1] - wr[1]) > 800: continue
            ch = [(s0,) + d]
            for i in range(s0 + 1, min(n, int(t0) + 28)):
                L = ch[-1]; k = i - L[0]
                if len(ch) > 1: p = ch[-2]; vx = (L[1] - p[1]) / (L[0] - p[0]); vy = (L[2] - p[2]) / (L[0] - p[0])
                else: vx, vy = 0, -40
                ex, ey = L[1] + vx * k, L[2] + vy * k; gate = 25 + 12 * k + 0.3 * np.hypot(vx, vy) * k
                cand = [(np.hypot(e[0] - ex, e[1] - ey), e) for e in dets(i, cam0, 0.12)]
                cand = [x for x in cand if x[0] < gate and x[1][2] <= L[3] * 1.35 + 3]
                if cand: ch.append((i,) + min(cand, key=lambda x: x[0])[1])
                if i - ch[-1][0] > 4: break
            if len(ch) >= 5 and ch[-1][2] < ch[0][2] - 60 and (best is None or len(ch) > len(best)): best = ch
    return best, cam0
shots = []
print(" shot  frame stroke  contact(audio snr)  ball pts  dist   speed   range(+-size err)  fit err")
for j, (c, st) in enumerate(P["shots"]):
    ta, snr = t_audio(c); t0 = ta if snr > 6 else c + 0.5
    rec = {"c": c, "f": int(round(t0)), "stroke": st, "speed": None, "track": []}
    best, cam0 = outgoing(c, t0)
    if best:
        a = np.array(best, dtype=float); t = (a[:, 0] - t0) / FPS
        w = np.median(sorted(a[:3, 3])[:2]); Z0 = f_px * BALL / w; u = a[:, 1] - SW / 2; v = a[:, 2] - SH / 2
        (X0, Y0, vx, vy, vz), err = fit(t, u, v, Z0); sp = float(np.sqrt(vx * vx + vy * vy + vz * vz) * 3.6)
        rng = [np.linalg.norm(fit(t, u, v, Z0 * s)[0][2:]) * 3.6 for s in (0.85, 1.18)]
        rec["track"] = [[int(x[0]), round(x[1] + (cam[int(x[0]), 0] - cam0[0]), 1), round(x[2] + (cam[int(x[0]), 1] - cam0[1]), 1)] for x in best]
        ok = err <= P.get("max_fit_err_px", 2.5) and 15 <= sp <= 180 and len(a) >= 8
        if ok: rec["speed"] = round(sp)
        print("%4d %6d   %s   %6.1f (%3.0f)     %3d    %4.1fm  %4.0f    %3.0f..%-3.0f  %5.1fpx %s" % (j + 1, c, st, t0, snr, len(a), Z0, sp, min(rng), max(rng), err, "" if ok else " <- rejected"))
    else:
        print("%4d %6d   %s   %6.1f (%3.0f)     no outgoing ball track" % (j + 1, c, st, t0, snr))
    shots.append(rec)
ov = P.get("speed_override", {})          # manual decisions after looking at the frames: {"620": null}
for s in shots:
    if str(s["c"]) in ov: s["speed"] = ov[str(s["c"])]
jsave(P, "analysis.json", {"shots": shots, "kp": K.round(1).tolist(), "pc": pc.round(1).tolist(), "n": n, "W": SW, "H": SH})
m = [s["speed"] for s in shots if s["speed"]]
print("measured %d/%d shots; shown as '≈' (±25%%), others '—'" % (len(m), len(shots)))
