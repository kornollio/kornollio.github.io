# camera pan (phase correlation of the band above the player) -> work/cam.json
# audio impact envelope (1 ms, 1.5-8 kHz) -> work/env.npy, and a list of loud transients (own racket hits)
import numpy as np, subprocess
from scipy.io import wavfile
from scipy.signal import butter, sosfilt, find_peaks
from common import *
P = load(); F = P["_fps"]
cap = cv2.VideoCapture(P["_video"]); prev = None; acc = np.zeros(2); out = []
while True:
    ok, fr = cap.read()
    if not ok: break
    h, w = fr.shape[:2]; s = 432 / w
    g = cv2.cvtColor(cv2.resize(fr, (432, int(h * s))), cv2.COLOR_BGR2GRAY).astype(np.float32)
    roi = g[int(g.shape[0] * 0.2):int(g.shape[0] * 0.43)]
    if prev is not None:
        (dx, dy), r = cv2.phaseCorrelate(prev, roi, cv2.createHanningWindow(roi.shape[::-1], cv2.CV_32F))
        if r > 0.05: acc = acc + np.array([dx, dy]) / s
    prev = roi; out.append(acc.round(1).tolist())
jsave(P, "cam.json", out)
wav = W(P, "audio.wav")
subprocess.run(["ffmpeg", "-v", "error", "-y", "-i", P["_video"], "-map", "0:a:0", "-ac", "1", "-ar", "48000", wav], check=True)
sr, x = wavfile.read(wav); x = x.astype(float) / 32768
y = sosfilt(butter(4, [1500, 8000], btype="band", fs=sr, output="sos"), x)
hop = sr // 1000; e = np.sqrt(np.convolve(y ** 2, np.ones(hop * 3) / (hop * 3), "same"))[::hop]
np.save(W(P, "env.npy"), e)
r = e / (np.convolve(e, np.ones(300) / 300, "same") + 1e-6)
pk, _ = find_peaks(r, height=6, distance=150)
print("camera frames", len(out)); print("loud transients (frame, snr):", [(round(p / 1000 * F, 1), round(float(r[p]), 1)) for p in pk])
