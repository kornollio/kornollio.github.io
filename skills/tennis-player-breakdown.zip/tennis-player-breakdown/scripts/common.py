# shared helpers: python <script> /path/project.json ...
import json, os, sys, cv2
CACHE = os.path.expanduser("~/.cache/tennis-rally-breakdown")
def load(path=None):
    pj = os.path.abspath(path or sys.argv[1]); P = json.load(open(pj))
    base = os.path.dirname(pj)
    P["_pj"] = pj; P["_base"] = base; P["_work"] = os.path.join(base, "work"); os.makedirs(P["_work"], exist_ok=True)
    P["_video"] = P["video"] if os.path.isabs(P["video"]) else os.path.join(base, P["video"])
    out = P.get("output", "breakdown.mp4"); P["_output"] = out if os.path.isabs(out) else os.path.join(base, out)
    cap = cv2.VideoCapture(P["_video"]); P["_fps"] = cap.get(cv2.CAP_PROP_FPS) or 29.97; cap.release()
    return P
def W(P, name): return os.path.join(P["_work"], name)
def jload(P, name): return json.load(open(W(P, name)))
def jsave(P, name, obj): json.dump(obj, open(W(P, name), "w"))
