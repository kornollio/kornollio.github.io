# render 1080x1920: follow-cam crop, white skeleton, ball trail, name/handle, stats panel; source audio muxed in
# usage: render.py project.json [--preview f1,f2,...]      (previews -> work/prev_<f>.jpg)
import subprocess, numpy as np
from PIL import Image, ImageDraw, ImageFont
from scipy.ndimage import gaussian_filter1d
from common import *
import styles
P = load(); A = jload(P, "analysis.json"); D = jload(P, "pose.json")["frames"]; cam = np.array(jload(P, "cam.json"))
FPS = P["_fps"]; OW, OH = 1080, 1920; SW, SH = A["W"], A["H"]; N = A["n"]; K = np.array(A["kp"]); PC = np.array(A["pc"])
PREVIEW = [int(x) for x in sys.argv[3].split(",")] if len(sys.argv) > 3 and sys.argv[2] == "--preview" else None
wi = 10 if P.get("hand", "R") == "R" else 9
shots = A["shots"]; NS = len(shots)

# ---------- ball trail: incoming chain found backwards from the contact + outgoing track from analyze.py
def dets(i, th):
    return [((b[0] + b[2]) / 2, (b[1] + b[3]) / 2, min(b[2] - b[0], b[3] - b[1])) for b in D[i]["ball"] if b[4] >= th and b[2] - b[0] < 70]
def chain_back(c):
    wr = K[c, wi, :2]; best = None
    for s0 in range(c - 1, c - 4, -1):
        for d in dets(s0, 0.5):
            if np.hypot(d[0] - wr[0], d[1] - wr[1]) > 450: continue
            ch = [(s0,) + d]
            for i in range(s0 - 1, max(0, c - 30), -1):
                L = ch[-1]; k = L[0] - i
                if len(ch) > 1: p = ch[-2]; vx = (L[1] - p[1]) / (p[0] - L[0]); vy = (L[2] - p[2]) / (p[0] - L[0])
                else: vx = vy = 0
                ex = L[1] + vx * k - (cam[L[0], 0] - cam[i, 0]); ey = L[2] + vy * k - (cam[L[0], 1] - cam[i, 1])
                cand = [(np.hypot(e[0] - ex, e[1] - ey), e) for e in dets(i, 0.3)]
                cand = [x for x in cand if x[0] < 30 + 15 * k + 0.3 * np.hypot(vx, vy) * k]
                if cand: ch.append((i,) + min(cand, key=lambda x: x[0])[1])
                if ch[-1][0] - i > 3: break
            if len(ch) >= 5 and (best is None or len(ch) > len(best)): best = ch
    return sorted(best) if best else []
trail = {}
for s in shots:
    for (i, x, y, *_) in chain_back(s["c"]): trail[i] = (x, y)
    for (i, x, y) in s["track"]: trail[i] = (x, y)
for i in sorted(trail):
    nb = [trail[j] for j in (i - 1, i + 1) if j in trail]
    if nb and min(np.hypot(trail[i][0] - q[0], trail[i][1] - q[1]) for q in nb) > 300: trail.pop(i)

# ---------- follow cam: player ~36% of the frame height, centre at 40% (above the panel); never upscale > source
Hc = gaussian_filter1d(np.clip(PC[:, 2] / P.get("player_height_frac", 0.36), SH / (SW / OW), SH), 15)
Hc = np.minimum(Hc, SH); Wc = Hc * OW / OH
Wc = np.minimum(Wc, SW); Hc = Wc * OH / OW
x0 = gaussian_filter1d(np.clip(PC[:, 0] - Wc / 2, 0, SW - Wc), 6); y0 = gaussian_filter1d(np.clip(PC[:, 1] - 0.40 * Hc, 0, SH - Hc), 6)
x0 = np.clip(x0, 0, SW - Wc); y0 = np.clip(y0, 0, SH - Hc)

# ---------- top overlay: name plate + handle
def camera_glyph(size):
    s = size * 4; im = Image.new("RGBA", (s, s), (0, 0, 0, 0)); d = ImageDraw.Draw(im); lw = int(s * 0.085); wh = (255, 255, 255, 255)
    d.rounded_rectangle([lw, lw, s - lw, s - lw], radius=int(s * 0.28), outline=wh, width=lw)
    r = s * 0.22; d.ellipse([s / 2 - r, s / 2 - r, s / 2 + r, s / 2 + r], outline=wh, width=lw)
    r2 = s * 0.055; d.ellipse([s * .73 - r2, s * .27 - r2, s * .73 + r2, s * .27 + r2], fill=wh)
    return im.resize((size, size), Image.LANCZOS)
top = Image.new("RGBA", (OW, OH), (0, 0, 0, 0)); td = ImageDraw.Draw(top)
if P.get("name"):
    td.rectangle([683, 82, 1031, 138], fill=(239, 238, 233, 240))
    td.text((857, 110), P["name"], font=ImageFont.truetype("/System/Library/Fonts/Menlo.ttc", 24, index=1), fill=(42, 122, 85), anchor="mm")
if P.get("handle"):
    hf = ImageFont.truetype("/System/Library/Fonts/Avenir Next Condensed.ttc", 34, index=0); h = P["handle"].upper()
    sh = Image.new("RGBA", (OW, OH), (0, 0, 0, 0)); sd = ImageDraw.Draw(sh)
    for dx in (2, 1): sd.text((995 + dx, 585 + dx), h, font=hf, fill=(0, 0, 0, 140), anchor="rm")
    top.alpha_composite(sh); top.alpha_composite(camera_glyph(58), (939, 476)); td.text((995, 585), h, font=hf, fill="white", anchor="rm")
TOP = np.array(top).astype(np.float32)
PANELS = [np.array(styles.build(P.get("style", "clay"), k, shots, P)).astype(np.float32) for k in range(NS + 1)]
contact = [s["f"] for s in shots]

SK = [(5, 6), (6, 12), (12, 11), (11, 5), (5, 7), (7, 9), (6, 8), (8, 10), (11, 13), (13, 15), (12, 14), (14, 16)]
def compose(i, fr):
    sx, sy, sc = x0[i], y0[i], OW / Wc[i]
    out = cv2.warpAffine(fr, np.float32([[sc, 0, -sx * sc], [0, sc, -sy * sc]]), (OW, OH), flags=cv2.INTER_AREA if sc < 1 else cv2.INTER_LINEAR)
    T = lambda p: (int(round((p[0] - sx) * sc * 4)), int(round((p[1] - sy) * sc * 4)))
    conf = np.array(D[i]["p"]["kp"])[:, 2]
    for a, b in SK:
        if conf[a] > 0.45 and conf[b] > 0.45: cv2.line(out, T(K[i, a]), T(K[i, b]), (255, 255, 255), 3, cv2.LINE_AA, shift=2)
    pts = [(j, trail[j]) for j in range(i - 7, i + 1) if j in trail]
    if pts and pts[-1][0] >= i - 1:
        for m in range(1, len(pts)):
            a = 0.25 + 0.75 * m / len(pts); ov = out.copy()
            cv2.line(ov, T(pts[m - 1][1]), T(pts[m][1]), (60, 235, 235), int(3 + 4 * m / len(pts)), cv2.LINE_AA, shift=2)
            out = cv2.addWeighted(ov, a, out, 1 - a, 0)
        if pts[-1][0] == i:
            c = T(pts[-1][1]); cv2.circle(out, c, 44, (90, 245, 240), -1, cv2.LINE_AA, shift=2); cv2.circle(out, c, 44, (40, 120, 120), 2, cv2.LINE_AA, shift=2)
    rgb = cv2.cvtColor(out, cv2.COLOR_BGR2RGB).astype(np.float32)
    a = TOP[..., 3:] / 255; rgb = rgb * (1 - a) + TOP[..., :3] * a
    o = PANELS[sum(1 for f in contact if f <= i)]; a = o[..., 3:] / 255; rgb = rgb * (1 - a) + o[..., :3] * a
    return np.clip(rgb, 0, 255).astype(np.uint8)

cap = cv2.VideoCapture(P["_video"])
if PREVIEW:
    for i in range(max(PREVIEW) + 1):
        ok, fr = cap.read()
        if i in PREVIEW: Image.fromarray(compose(i, fr)).save(W(P, "prev_%d.jpg" % i), quality=90); print(W(P, "prev_%d.jpg" % i))
    sys.exit()
tmp = W(P, "video.mp4")
ff = subprocess.Popen(["ffmpeg", "-v", "error", "-y", "-f", "rawvideo", "-pix_fmt", "rgb24", "-s", "%dx%d" % (OW, OH), "-r", str(FPS), "-i", "-",
                       "-c:v", "libx264", "-preset", "medium", "-crf", "18", "-pix_fmt", "yuv420p", tmp], stdin=subprocess.PIPE)
for i in range(N):
    ok, fr = cap.read()
    if not ok: break
    ff.stdin.write(compose(i, fr).tobytes())
    if i % 200 == 0: print(i, "/", N, flush=True)
ff.stdin.close(); ff.wait()
dur = float(subprocess.run(["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "csv=p=0", tmp], capture_output=True, text=True).stdout)
subprocess.run(["ffmpeg", "-v", "error", "-y", "-i", tmp, "-i", P["_video"], "-map", "0:v", "-map", "1:a:0?", "-c:v", "copy",
                "-af", "afade=t=out:st=%.2f:d=1" % max(0, dur - 1), "-c:a", "aac", "-b:a", "192k", "-t", "%.3f" % dur,
                "-movflags", "+faststart", P["_output"]], check=True)
print("done ->", P["_output"])
