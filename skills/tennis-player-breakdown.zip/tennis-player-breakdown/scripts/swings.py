# swing candidates = peaks of the dominant wrist speed (torso-normalised), with backswing side hint
# usage: swings.py project.json      -> prints candidates and writes work/cand.jpg (player-cropped sheet)
import numpy as np
from scipy.signal import find_peaks
from scipy.ndimage import gaussian_filter1d
from common import *
import sheet
P = load(); D = jload(P, "pose.json"); F = D["frames"]; n = len(F)
wi = 10 if P.get("hand", "R") == "R" else 9; oi = 19 - wi
kp = lambda i, j: np.array(F[i]["p"]["kp"][j]) if F[i]["p"] else np.array([np.nan] * 3)
A = lambda j: np.array([kp(i, j) for i in range(n)])
LS, RS, LH, RH, WR, WO = A(5), A(6), A(11), A(12), A(wi), A(oi)
hip = (LH[:, :2] + RH[:, :2]) / 2
torso = np.hypot(*((LS[:, :2] + RS[:, :2]) / 2 - hip).T)
torso = gaussian_filter1d(np.where(np.isnan(torso), np.nanmedian(torso), torso), 5)
def rel(Wr):
    r = (Wr[:, :2] - hip) / torso[:, None]
    for k in range(2):
        ok = ~np.isnan(r[:, k]); r[:, k] = np.interp(np.arange(n), np.where(ok)[0], r[ok, k])
    return r
r, ro = rel(WR), rel(WO)
v = gaussian_filter1d(np.r_[np.hypot(*np.diff(r, axis=0).T), 0], 1.5)
pk, _ = find_peaks(v, height=0.12, distance=18, prominence=0.06)
sgn = 1 if wi == 10 else -1   # from behind: dominant side = image right for a right-hander
print("frame  speed  backswing-side(+ = dominant side -> FH, - -> BH)")
for p in pk:
    a = max(0, p - 12); side = sgn * np.nanmean(r[a:p - 2, 0])
    print("%5d  %.2f   %+.2f  %s" % (p, v[p], side, "FH?" if side > 0.25 else "BH?" if side < -0.25 else "?"))
sheet.crops(P, W(P, "cand.jpg"), [int(p) for p in pk], -16, 9, 2)
print("sheet:", W(P, "cand.jpg"), "(magenta = speed peak; a peak is often the follow-through, the contact is a few frames earlier)")
