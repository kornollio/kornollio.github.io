# project.json

Keep it in a folder next to the video; relative paths are resolved from the project folder.
Intermediate files go to `<project dir>/work/`.

```json
{
  "video": "../player.MP4",                       // source clip (vertical, follows one player)
  "output": "../Игрок — разбор розыгрыша.mp4",   // final file, source audio muxed in
  "lang": "ru",                                   // "ru" | "en" — panel labels
  "style": "clay",                                // "clay" (default) | "broadcast" | "minimal"
  "name": "Иван",                               // plate top-right; omit for none
  "handle": "@your_handle",                     // camera glyph + handle on the right; omit for none
  "hand": "R",                                    // "R" | "L" — dominant hand of the player
  "focal_px": 1700,                               // focal length in px of the decoded frame (Osmo Pocket 1728×3072 ≈ 1700)
  "player_height_frac": 0.36,                     // follow-cam: player box height / output height (optional)
  "max_fit_err_px": 2.5,                          // speed fit acceptance (optional)
  "shots": [[21, "FH"], [143, "FH"], [244, "BH"]], // visual contact frame (OpenCV index) + stroke, confirmed by eye
  "speed_override": {"620": null}                 // optional manual rejections after checking frames
}
```

## work/
- `pose.json` — per frame: followed player's box + 17 COCO keypoints, racket boxes, ball boxes (track.py)
- `cam.json` — cumulative camera pan in source px (camaudio.py)
- `audio.wav`, `env.npy` — 1 ms impact envelope (camaudio.py)
- `cand.jpg`, `sheet_<f>.jpg` — stroke-checking sheets (swings.py, sheet.py)
- `analysis.json` — smoothed keypoints, follow-cam data, shots with audio contact frame, speed, outgoing track (analyze.py)
- `prev_<f>.jpg`, `video.mp4` — previews and the silent render (render.py)
